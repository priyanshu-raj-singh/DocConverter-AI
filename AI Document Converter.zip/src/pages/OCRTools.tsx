import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  ScanText, 
  Download,
  FileText,
  Image,
  Languages,
  Eye,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Target,
  Clock,
  FileImage,
  Type,
  PenTool
} from 'lucide-react';
import { toast } from 'sonner';

interface OCRJob {
  id: string;
  fileName: string;
  fileSize: number;
  ocrType: string;
  status: 'uploading' | 'scanning' | 'processing' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  settings?: any;
  confidence?: number;
  wordsDetected?: number;
}

const ocrTypes = {
  text: {
    title: 'Text Recognition',
    icon: Type,
    color: 'bg-blue-500',
    description: 'Extract printed text from images and scanned documents',
    formats: ['Plain Text', 'Formatted Text', 'Searchable PDF', 'Word Document'],
    fileTypes: ['.pdf', '.jpg', '.jpeg', '.png', '.bmp', '.tiff']
  },
  handwriting: {
    title: 'Handwriting Recognition',
    icon: PenTool,
    color: 'bg-purple-500',
    description: 'Convert handwritten text to digital format',
    formats: ['Plain Text', 'Structured Notes', 'Formatted Document'],
    fileTypes: ['.jpg', '.jpeg', '.png', '.pdf']
  },
  multilang: {
    title: 'Multi-Language OCR',
    icon: Languages,
    color: 'bg-green-500',
    description: 'Recognize text in multiple languages simultaneously',
    formats: ['UTF-8 Text', 'Translated Text', 'Bilingual Document'],
    fileTypes: ['.pdf', '.jpg', '.jpeg', '.png', '.bmp', '.tiff']
  },
  table: {
    title: 'Table Extraction',
    icon: FileText,
    color: 'bg-orange-500',
    description: 'Extract and structure tables from documents',
    formats: ['CSV Format', 'Excel Spreadsheet', 'JSON Data', 'HTML Table'],
    fileTypes: ['.pdf', '.jpg', '.jpeg', '.png']
  }
};

const languages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ru', name: 'Russian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'zh', name: 'Chinese' },
  { code: 'ar', name: 'Arabic' },
  { code: 'hi', name: 'Hindi' }
];

export default function OCRTools() {
  const [jobs, setJobs] = useState<OCRJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [ocrSettings, setOcrSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File, ocrType: string): { valid: boolean; error?: string } => {
    const allowedTypes = ocrTypes[ocrType as keyof typeof ocrTypes]?.fileTypes || [];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!allowedTypes.includes(fileExtension)) {
      return {
        valid: false,
        error: `File type ${fileExtension} not supported for ${ocrTypes[ocrType as keyof typeof ocrTypes]?.title}`
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, ocrType: string): number => {
    const baseTime = {
      'text': 8,
      'handwriting': 15,
      'multilang': 12,
      'table': 10
    }[ocrType] || 10;

    const sizeTime = Math.ceil(fileSize / (2 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, ocrType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, ocrType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, ocrType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, ocrType);
  };

  const handleFiles = (files: File[], ocrType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file, ocrType);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(prev => ({
      ...prev,
      [ocrType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, ocrType);
      
      const newJob: OCRJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        ocrType,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        settings: ocrSettings[ocrType] || {}
      };

      setJobs(prev => [...prev, newJob]);
      simulateOCRProcessing(jobId, estimatedTime, ocrType);
    });

    toast.success(`Started ${ocrTypes[ocrType as keyof typeof ocrTypes].title} for ${validFiles.length} file(s)`);
  };

  const simulateOCRProcessing = (jobId: string, estimatedTime: number, ocrType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (20% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 200;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 10 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'scanning', progress: 0 }
            : job
        ));

        // Simulate scanning (40% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'processing', progress: 0 }
              : job
          ));

          // Simulate processing (40% of total time)
          const processingDuration = estimatedTime * 400;
          const processingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 4 + 2;
                if (newProgress >= 100) {
                  clearInterval(processingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate OCR result
                  const confidence = Math.floor(Math.random() * 15) + 85; // 85-99%
                  const wordsDetected = Math.floor(Math.random() * 500) + 100;
                  const result = generateOCRResult(ocrType, job.settings, confidence, wordsDetected);
                  const downloadBlob = createOCRFile(ocrType, job.fileName, result, job.settings);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result: getOCRResultSummary(ocrType, confidence, wordsDetected),
                    confidence,
                    wordsDetected
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, processingDuration / 50);
        }, estimatedTime * 400);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateOCRResult = (ocrType: string, settings: any, confidence: number, wordsDetected: number): string => {
    switch (ocrType) {
      case 'text':
        return generateTextOCR(settings, confidence, wordsDetected);
      case 'handwriting':
        return generateHandwritingOCR(settings, confidence, wordsDetected);
      case 'multilang':
        return generateMultiLangOCR(settings, confidence, wordsDetected);
      case 'table':
        return generateTableOCR(settings, confidence, wordsDetected);
      default:
        return 'OCR processing completed successfully';
    }
  };

  const generateTextOCR = (settings: any, confidence: number, wordsDetected: number): string => {
    const format = settings?.format || 'Plain Text';
    
    let text = `# OCR Text Recognition Results\n\n`;
    text += `**Confidence:** ${confidence}%\n`;
    text += `**Words Detected:** ${wordsDetected}\n`;
    text += `**Format:** ${format}\n\n`;
    text += `## Extracted Text\n\n`;
    
    // Sample extracted text
    text += `This is a sample of extracted text from your document. The OCR engine has successfully identified and converted the visual text into machine-readable format.\n\n`;
    text += `Key features detected:\n`;
    text += `• High-quality text recognition\n`;
    text += `• Proper formatting preservation\n`;
    text += `• Special character handling\n`;
    text += `• Multi-column layout support\n\n`;
    text += `The original document structure has been maintained where possible, ensuring accurate representation of the source material.`;
    
    return text;
  };

  const generateHandwritingOCR = (settings: any, confidence: number, wordsDetected: number): string => {
    const format = settings?.format || 'Plain Text';
    
    let text = `# Handwriting Recognition Results\n\n`;
    text += `**Confidence:** ${confidence}%\n`;
    text += `**Words Detected:** ${wordsDetected}\n`;
    text += `**Format:** ${format}\n\n`;
    text += `## Recognized Handwriting\n\n`;
    
    text += `Sample handwritten text has been successfully converted to digital format. The handwriting recognition engine analyzed pen strokes, letter formations, and writing patterns.\n\n`;
    text += `Recognition quality factors:\n`;
    text += `• Writing clarity: Excellent\n`;
    text += `• Letter spacing: Good\n`;
    text += `• Ink consistency: Very Good\n`;
    text += `• Overall legibility: ${confidence > 90 ? 'Excellent' : confidence > 80 ? 'Good' : 'Fair'}\n\n`;
    text += `Note: Some ambiguous characters may require manual review for complete accuracy.`;
    
    return text;
  };

  const generateMultiLangOCR = (settings: any, confidence: number, wordsDetected: number): string => {
    const languages = settings?.languages || ['English', 'Spanish'];
    
    let text = `# Multi-Language OCR Results\n\n`;
    text += `**Confidence:** ${confidence}%\n`;
    text += `**Words Detected:** ${wordsDetected}\n`;
    text += `**Languages Detected:** ${languages.join(', ')}\n\n`;
    text += `## Extracted Multi-Language Text\n\n`;
    
    text += `The document contains text in multiple languages. Each language segment has been identified and processed accordingly.\n\n`;
    text += `### English Section\n`;
    text += `This is the English portion of the document with standard Latin characters and English grammar patterns.\n\n`;
    text += `### Secondary Language Section\n`;
    text += `Additional language content has been detected and processed with appropriate character recognition models.\n\n`;
    text += `**Language Detection Accuracy:** ${confidence}%\n`;
    text += `**Character Set Support:** Unicode compliant`;
    
    return text;
  };

  const generateTableOCR = (settings: any, confidence: number, wordsDetected: number): string => {
    const format = settings?.format || 'CSV Format';
    
    if (format === 'CSV Format') {
      let csv = `# Table Extraction Results\n\n`;
      csv += `**Confidence:** ${confidence}%\n`;
      csv += `**Data Points:** ${wordsDetected}\n`;
      csv += `**Format:** ${format}\n\n`;
      csv += `## Extracted Table Data\n\n`;
      csv += `Header 1,Header 2,Header 3,Header 4\n`;
      csv += `Data 1,Value A,123.45,Active\n`;
      csv += `Data 2,Value B,678.90,Inactive\n`;
      csv += `Data 3,Value C,234.56,Pending\n`;
      csv += `Data 4,Value D,789.01,Active\n`;
      csv += `Data 5,Value E,345.67,Completed\n\n`;
      csv += `Table structure preserved with ${Math.floor(wordsDetected / 20)} rows and 4 columns detected.`;
      return csv;
    }
    
    return `Table extraction completed in ${format} format with ${confidence}% confidence.`;
  };

  const createOCRFile = (ocrType: string, fileName: string, content: string, settings: any): Blob => {
    const format = settings?.format || ocrTypes[ocrType as keyof typeof ocrTypes]?.formats[0];
    
    switch (format) {
      case 'Plain Text':
      case 'Formatted Text':
      case 'Structured Notes':
      case 'UTF-8 Text':
        return new Blob([content], { type: 'text/plain; charset=utf-8' });
      case 'Word Document':
        return downloadUtils.createWord(fileName, content);
      case 'Searchable PDF':
        return downloadUtils.createPDF(fileName, content);
      case 'CSV Format':
        return new Blob([content], { type: 'text/csv' });
      case 'Excel Spreadsheet':
        return downloadUtils.createExcel(fileName);
      case 'JSON Data':
        const jsonData = {
          fileName,
          extractedText: content,
          confidence: 95,
          timestamp: new Date().toISOString()
        };
        return new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
      case 'HTML Table':
        const htmlContent = `<!DOCTYPE html>
<html>
<head><title>Extracted Table - ${fileName}</title></head>
<body>
<h1>Table Extraction Results</h1>
<pre>${content}</pre>
</body>
</html>`;
        return new Blob([htmlContent], { type: 'text/html' });
      default:
        return new Blob([content], { type: 'text/plain' });
    }
  };

  const getOCRResultSummary = (ocrType: string, confidence: number, wordsDetected: number): string => {
    const typeName = ocrTypes[ocrType as keyof typeof ocrTypes]?.title;
    return `${typeName} completed with ${confidence}% confidence. Detected ${wordsDetected} words/data points. Ready for download.`;
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateOCRProcessing(jobId, job.estimatedTime || 10, job.ocrType);
    }
  };

  const getStatusIcon = (status: OCRJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'scanning':
        return <ScanText className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'processing':
        return <Eye className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: OCRJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'scanning':
        return 'Scanning Document...';
      case 'processing':
        return 'Processing Text...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const getFileExtension = (format: string): string => {
    switch (format) {
      case 'Plain Text':
      case 'Formatted Text':
      case 'Structured Notes':
      case 'UTF-8 Text':
        return 'txt';
      case 'Word Document':
        return 'docx';
      case 'Searchable PDF':
        return 'pdf';
      case 'CSV Format':
        return 'csv';
      case 'Excel Spreadsheet':
        return 'xlsx';
      case 'JSON Data':
        return 'json';
      case 'HTML Table':
        return 'html';
      default:
        return 'txt';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <ScanText className="h-8 w-8 text-primary floating" />
            OCR Tools
          </h1>
          <p className="text-muted-foreground">
            Extract text from images and scanned documents with advanced OCR technology
          </p>
        </div>

        <Tabs defaultValue="text" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="text" className="flex items-center gap-2">
              <Type className="h-4 w-4" />
              Text OCR
            </TabsTrigger>
            <TabsTrigger value="handwriting" className="flex items-center gap-2">
              <PenTool className="h-4 w-4" />
              Handwriting
            </TabsTrigger>
            <TabsTrigger value="multilang" className="flex items-center gap-2">
              <Languages className="h-4 w-4" />
              Multi-Language
            </TabsTrigger>
            <TabsTrigger value="table" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Tables
            </TabsTrigger>
          </TabsList>

          {Object.entries(ocrTypes).map(([key, type]) => (
            <TabsContent key={key} value={key} className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card className="conversion-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <type.icon className="h-5 w-5" />
                        {type.title}
                      </CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Output Format Selection */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Output Format:</h4>
                        <div className="grid grid-cols-2 gap-3">
                          {type.formats.map((format) => (
                            <Button
                              key={format}
                              variant={ocrSettings[key]?.format === format ? "default" : "outline"}
                              className="justify-start h-auto p-3"
                              onClick={() => setOcrSettings(prev => ({
                                ...prev,
                                [key]: { ...prev[key], format }
                              }))}
                            >
                              <span className="text-sm">{format}</span>
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* Language Selection for Multi-Language OCR */}
                      {key === 'multilang' && (
                        <div className="space-y-4">
                          <h4 className="font-medium">Target Languages:</h4>
                          <Select
                            value={ocrSettings[key]?.primaryLanguage || 'en'}
                            onValueChange={(value) => setOcrSettings(prev => ({
                              ...prev,
                              [key]: { ...prev[key], primaryLanguage: value }
                            }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select primary language" />
                            </SelectTrigger>
                            <SelectContent>
                              {languages.map((lang) => (
                                <SelectItem key={lang.code} value={lang.code}>
                                  {lang.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      {/* File Preview */}
                      {selectedFiles[key]?.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(key)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {selectedFiles[key].slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {selectedFiles[key].length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{selectedFiles[key].length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      {/* Upload Area */}
                      <div
                        className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, key)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, key)}
                      >
                        <div className="floating">
                          <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <h3 className="font-semibold mb-2">Upload Files for {type.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          Supported formats: {type.fileTypes.join(', ')}
                        </p>
                        <p className="text-sm text-muted-foreground mb-4">
                          Drag & drop your files here or click to browse
                        </p>
                        <input
                          ref={el => fileInputRefs.current[key] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${key}`}
                          accept={type.fileTypes.join(',')}
                          onChange={(e) => handleFileSelect(e, key)}
                        />
                        <Button 
                          variant="outline"
                          onClick={() => {
                            const input = document.getElementById(`file-${key}`) as HTMLInputElement;
                            if (input) {
                              input.click();
                            } else {
                              console.error('File input not found:', `file-${key}`);
                              toast.error('File input not available. Please refresh the page.');
                            }
                          }}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Select Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {key === 'text' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Type className="h-4 w-4 text-blue-500" />
                            <span>High accuracy text recognition</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <FileText className="h-4 w-4 text-green-500" />
                            <span>Format preservation</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-yellow-500" />
                            <span>Fast processing</span>
                          </div>
                        </>
                      )}
                      {key === 'handwriting' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <PenTool className="h-4 w-4 text-purple-500" />
                            <span>Cursive & print recognition</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Eye className="h-4 w-4 text-blue-500" />
                            <span>Stroke analysis</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-green-500" />
                            <span>High precision algorithms</span>
                          </div>
                        </>
                      )}
                      {key === 'multilang' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Languages className="h-4 w-4 text-green-500" />
                            <span>50+ languages supported</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Type className="h-4 w-4 text-blue-500" />
                            <span>Unicode character support</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-purple-500" />
                            <span>Auto language detection</span>
                          </div>
                        </>
                      )}
                      {key === 'table' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <FileText className="h-4 w-4 text-orange-500" />
                            <span>Table structure detection</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-blue-500" />
                            <span>Cell boundary recognition</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-green-500" />
                            <span>Multiple export formats</span>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        Processing Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Text OCR:</span>
                        <span className="text-muted-foreground">5-15 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Handwriting:</span>
                        <span className="text-muted-foreground">10-25 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Multi-language:</span>
                        <span className="text-muted-foreground">8-20 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Table extraction:</span>
                        <span className="text-muted-foreground">6-18 seconds</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* OCR Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ScanText className="h-5 w-5" />
                OCR Processing Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your OCR processing tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileImage className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {ocrTypes[job.ocrType as keyof typeof ocrTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.confidence && (
                            <span className="text-green-600">{job.confidence}% confidence</span>
                          )}
                          {job.wordsDetected && (
                            <span>{job.wordsDetected} words</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            const ocrName = ocrTypes[job.ocrType as keyof typeof ocrTypes]?.title.toLowerCase().replace(/\s+/g, '-');
                            const extension = getFileExtension(job.settings?.format || 'Plain Text');
                            link.download = `${ocrName}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${extension}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('OCR result downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'scanning' || job.status === 'processing') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'scanning' && 'Scanning document...'}
                          {job.status === 'processing' && 'Processing text...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">OCR Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}