import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  FileInput, 
  Download,
  FileText,
  User,
  Building,
  CreditCard,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Target,
  Clock,
  Brain,
  FormInput,
  Save
} from 'lucide-react';
import { toast } from 'sonner';

interface AutoFillJob {
  id: string;
  fileName: string;
  fileSize: number;
  formType: string;
  status: 'uploading' | 'analyzing' | 'filling' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  fieldsDetected?: number;
  fieldsFilled?: number;
}

interface FormData {
  personal: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
    dateOfBirth: string;
    ssn: string;
  };
  business: {
    companyName: string;
    jobTitle: string;
    department: string;
    workPhone: string;
    workEmail: string;
    companyAddress: string;
    taxId: string;
    industry: string;
  };
  financial: {
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    income: string;
    creditScore: string;
    employmentStatus: string;
  };
}

const formTypes = {
  personal: {
    title: 'Personal Forms',
    icon: User,
    color: 'bg-blue-500',
    description: 'Auto-fill personal information forms and applications',
    examples: ['Job Applications', 'Insurance Forms', 'Government Forms', 'Registration Forms']
  },
  business: {
    title: 'Business Forms',
    icon: Building,
    color: 'bg-green-500',
    description: 'Complete business and corporate forms automatically',
    examples: ['Vendor Applications', 'Contract Forms', 'Tax Documents', 'Compliance Forms']
  },
  financial: {
    title: 'Financial Forms',
    icon: CreditCard,
    color: 'bg-purple-500',
    description: 'Fill out financial and banking forms with secure data',
    examples: ['Loan Applications', 'Credit Applications', 'Banking Forms', 'Investment Forms']
  },
  custom: {
    title: 'Custom Forms',
    icon: FormInput,
    color: 'bg-orange-500',
    description: 'AI-powered form filling for any type of document',
    examples: ['Survey Forms', 'Medical Forms', 'Educational Forms', 'Legal Documents']
  }
};

export default function AutoFillForms() {
  const [jobs, setJobs] = useState<AutoFillJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [formData, setFormData] = useState<FormData>({
    personal: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      dateOfBirth: '',
      ssn: ''
    },
    business: {
      companyName: '',
      jobTitle: '',
      department: '',
      workPhone: '',
      workEmail: '',
      companyAddress: '',
      taxId: '',
      industry: ''
    },
    financial: {
      bankName: '',
      accountNumber: '',
      routingNumber: '',
      income: '',
      creditScore: '',
      employmentStatus: ''
    }
  });
  const [activeTab, setActiveTab] = useState('personal');
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for form auto-fill'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, formType: string): number => {
    const baseTime = {
      'personal': 8,
      'business': 10,
      'financial': 12,
      'custom': 15
    }[formType] || 10;

    const sizeTime = Math.ceil(fileSize / (3 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, formType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, formType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, formType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, formType);
  };

  const handleFiles = (files: File[], formType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    // Check if form data is filled for the selected type
    const currentFormData = formData[formType as keyof FormData];
    const hasData = Object.values(currentFormData).some(value => value.trim() !== '');
    
    if (!hasData) {
      toast.error(`Please fill in your ${formType} information first before processing forms.`);
      return;
    }

    setSelectedFiles(prev => ({
      ...prev,
      [formType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, formType);
      
      const newJob: AutoFillJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        formType,
        status: 'uploading',
        progress: 0,
        estimatedTime
      };

      setJobs(prev => [...prev, newJob]);
      simulateAutoFill(jobId, estimatedTime, formType);
    });

    toast.success(`Started auto-fill for ${validFiles.length} form(s)`);
  };

  const simulateAutoFill = (jobId: string, estimatedTime: number, formType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (20% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 200;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 10 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'analyzing', progress: 0 }
            : job
        ));

        // Simulate form analysis (30% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'filling', progress: 0 }
              : job
          ));

          // Simulate form filling (50% of total time)
          const fillingDuration = estimatedTime * 500;
          const fillingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 4 + 2;
                if (newProgress >= 100) {
                  clearInterval(fillingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate result
                  const fieldsDetected = Math.floor(Math.random() * 20) + 10;
                  const fieldsFilled = Math.floor(fieldsDetected * 0.85) + Math.floor(Math.random() * 3);
                  const result = generateAutoFillResult(formType, fieldsDetected, fieldsFilled);
                  const downloadBlob = createFilledForm(formType, job.fileName, fieldsDetected, fieldsFilled);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result,
                    fieldsDetected,
                    fieldsFilled
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, fillingDuration / 50);
        }, estimatedTime * 300);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateAutoFillResult = (formType: string, fieldsDetected: number, fieldsFilled: number): string => {
    const typeName = formTypes[formType as keyof typeof formTypes]?.title;
    const fillRate = Math.round((fieldsFilled / fieldsDetected) * 100);
    return `${typeName} auto-fill completed. Detected ${fieldsDetected} fields, filled ${fieldsFilled} (${fillRate}% success rate). Form ready for review and submission.`;
  };

  const createFilledForm = (formType: string, fileName: string, fieldsDetected: number, fieldsFilled: number): Blob => {
    const currentFormData = formData[formType as keyof FormData];
    
    let content = `# Auto-Filled Form: ${fileName}\n\n`;
    content += `**Form Type:** ${formTypes[formType as keyof typeof formTypes]?.title}\n`;
    content += `**Processing Date:** ${new Date().toLocaleString()}\n`;
    content += `**Fields Detected:** ${fieldsDetected}\n`;
    content += `**Fields Filled:** ${fieldsFilled}\n`;
    content += `**Success Rate:** ${Math.round((fieldsFilled / fieldsDetected) * 100)}%\n\n`;
    
    content += `## Filled Information\n\n`;
    
    Object.entries(currentFormData).forEach(([key, value]) => {
      if (value.trim()) {
        const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        content += `**${label}:** ${value}\n`;
      }
    });
    
    content += `\n## Form Processing Notes\n\n`;
    content += `- All detected form fields have been analyzed\n`;
    content += `- Personal information has been automatically populated\n`;
    content += `- Please review all filled fields before submission\n`;
    content += `- Some fields may require manual verification\n`;
    content += `- Sensitive information has been handled securely\n\n`;
    
    content += `## Next Steps\n\n`;
    content += `1. Review all auto-filled information for accuracy\n`;
    content += `2. Complete any remaining empty fields manually\n`;
    content += `3. Verify all data before final submission\n`;
    content += `4. Save a copy for your records\n`;
    
    return downloadUtils.createPDF(fileName, content);
  };

  const updateFormData = (category: keyof FormData, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [field]: value
      }
    }));
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateAutoFill(jobId, job.estimatedTime || 10, job.formType);
    }
  };

  const getStatusIcon = (status: AutoFillJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'analyzing':
        return <Brain className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'filling':
        return <FileInput className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: AutoFillJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'analyzing':
        return 'Analyzing Form...';
      case 'filling':
        return 'Filling Fields...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const renderFormFields = (category: keyof FormData) => {
    const data = formData[category];
    
    switch (category) {
      case 'personal':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                value={data.firstName}
                onChange={(e) => updateFormData('personal', 'firstName', e.target.value)}
                placeholder="Enter first name"
              />
            </div>
            <div>
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                value={data.lastName}
                onChange={(e) => updateFormData('personal', 'lastName', e.target.value)}
                placeholder="Enter last name"
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={data.email}
                onChange={(e) => updateFormData('personal', 'email', e.target.value)}
                placeholder="Enter email address"
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={data.phone}
                onChange={(e) => updateFormData('personal', 'phone', e.target.value)}
                placeholder="Enter phone number"
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={data.address}
                onChange={(e) => updateFormData('personal', 'address', e.target.value)}
                placeholder="Enter street address"
              />
            </div>
            <div>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                value={data.city}
                onChange={(e) => updateFormData('personal', 'city', e.target.value)}
                placeholder="Enter city"
              />
            </div>
            <div>
              <Label htmlFor="state">State</Label>
              <Input
                id="state"
                value={data.state}
                onChange={(e) => updateFormData('personal', 'state', e.target.value)}
                placeholder="Enter state"
              />
            </div>
            <div>
              <Label htmlFor="zipCode">ZIP Code</Label>
              <Input
                id="zipCode"
                value={data.zipCode}
                onChange={(e) => updateFormData('personal', 'zipCode', e.target.value)}
                placeholder="Enter ZIP code"
              />
            </div>
            <div>
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={data.dateOfBirth}
                onChange={(e) => updateFormData('personal', 'dateOfBirth', e.target.value)}
              />
            </div>
          </div>
        );
        
      case 'business':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                value={data.companyName}
                onChange={(e) => updateFormData('business', 'companyName', e.target.value)}
                placeholder="Enter company name"
              />
            </div>
            <div>
              <Label htmlFor="jobTitle">Job Title</Label>
              <Input
                id="jobTitle"
                value={data.jobTitle}
                onChange={(e) => updateFormData('business', 'jobTitle', e.target.value)}
                placeholder="Enter job title"
              />
            </div>
            <div>
              <Label htmlFor="department">Department</Label>
              <Input
                id="department"
                value={data.department}
                onChange={(e) => updateFormData('business', 'department', e.target.value)}
                placeholder="Enter department"
              />
            </div>
            <div>
              <Label htmlFor="workPhone">Work Phone</Label>
              <Input
                id="workPhone"
                value={data.workPhone}
                onChange={(e) => updateFormData('business', 'workPhone', e.target.value)}
                placeholder="Enter work phone"
              />
            </div>
            <div>
              <Label htmlFor="workEmail">Work Email</Label>
              <Input
                id="workEmail"
                type="email"
                value={data.workEmail}
                onChange={(e) => updateFormData('business', 'workEmail', e.target.value)}
                placeholder="Enter work email"
              />
            </div>
            <div>
              <Label htmlFor="industry">Industry</Label>
              <Select
                value={data.industry}
                onValueChange={(value) => updateFormData('business', 'industry', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label htmlFor="companyAddress">Company Address</Label>
              <Textarea
                id="companyAddress"
                value={data.companyAddress}
                onChange={(e) => updateFormData('business', 'companyAddress', e.target.value)}
                placeholder="Enter company address"
                rows={2}
              />
            </div>
          </div>
        );
        
      case 'financial':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bankName">Bank Name</Label>
              <Input
                id="bankName"
                value={data.bankName}
                onChange={(e) => updateFormData('financial', 'bankName', e.target.value)}
                placeholder="Enter bank name"
              />
            </div>
            <div>
              <Label htmlFor="income">Annual Income</Label>
              <Input
                id="income"
                value={data.income}
                onChange={(e) => updateFormData('financial', 'income', e.target.value)}
                placeholder="Enter annual income"
              />
            </div>
            <div>
              <Label htmlFor="employmentStatus">Employment Status</Label>
              <Select
                value={data.employmentStatus}
                onValueChange={(value) => updateFormData('financial', 'employmentStatus', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select employment status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="employed">Employed</SelectItem>
                  <SelectItem value="self-employed">Self-Employed</SelectItem>
                  <SelectItem value="unemployed">Unemployed</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                  <SelectItem value="student">Student</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="creditScore">Credit Score Range</Label>
              <Select
                value={data.creditScore}
                onValueChange={(value) => updateFormData('financial', 'creditScore', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select credit score range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">Excellent (750+)</SelectItem>
                  <SelectItem value="good">Good (700-749)</SelectItem>
                  <SelectItem value="fair">Fair (650-699)</SelectItem>
                  <SelectItem value="poor">Poor (600-649)</SelectItem>
                  <SelectItem value="bad">Bad (Below 600)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <FileInput className="h-8 w-8 text-primary floating" />
            Auto-Fill Forms
          </h1>
          <p className="text-muted-foreground">
            Automatically fill out PDF forms using your saved information
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Form Data Input */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Your Information
                </CardTitle>
                <CardDescription>
                  Fill in your details to auto-populate forms
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex space-x-1 bg-muted p-1 rounded-lg">
                  <Button
                    variant={activeTab === 'personal' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('personal')}
                    className="flex-1"
                  >
                    Personal
                  </Button>
                  <Button
                    variant={activeTab === 'business' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('business')}
                    className="flex-1"
                  >
                    Business
                  </Button>
                  <Button
                    variant={activeTab === 'financial' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('financial')}
                    className="flex-1"
                  >
                    Financial
                  </Button>
                </div>

                <div className="space-y-4">
                  {renderFormFields(activeTab as keyof FormData)}
                </div>

                <Button className="w-full" variant="outline">
                  <Save className="h-4 w-4 mr-2" />
                  Save Information
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Form Processing */}
          <div className="lg:col-span-2 space-y-6">
            {Object.entries(formTypes).map(([key, type]) => (
              <Card key={key} className="conversion-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <type.icon className="h-5 w-5" />
                    {type.title}
                  </CardTitle>
                  <CardDescription>{type.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Examples */}
                  <div>
                    <h4 className="font-medium mb-2">Common Form Types:</h4>
                    <div className="flex flex-wrap gap-2">
                      {type.examples.map((example, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {example}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* File Preview */}
                  {selectedFiles[key]?.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Selected Files:</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => clearFiles(key)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      {selectedFiles[key].slice(0, 2).map((file, index) => (
                        <div key={index} className="file-preview">
                          <div className="flex items-center gap-2">
                            <FileCheck className="h-4 w-4 text-green-500" />
                            <span className="text-sm truncate flex-1">{file.name}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatFileSize(file.size)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Upload Area */}
                  <div
                    className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                    onDragOver={(e) => handleDragOver(e, key)}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, key)}
                  >
                    <div className="floating">
                      <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                    </div>
                    <h3 className="font-semibold mb-2">Upload {type.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Drag & drop PDF forms here or click to browse
                    </p>
                    <input
                      ref={el => fileInputRefs.current[key] = el}
                      type="file"
                      multiple
                      className="hidden"
                      id={`file-${key}`}
                      accept=".pdf"
                      onChange={(e) => handleFileSelect(e, key)}
                    />
                    <Button 
                      variant="outline"
                      onClick={() => {
                        const input = document.getElementById(`file-${key}`) as HTMLInputElement;
                        if (input) {
                          input.click();
                        } else {
                          console.error('File input not found:', `file-${key}`);
                          toast.error('File input not available. Please refresh the page.');
                        }
                      }}
                      className="transition-all duration-200 hover:scale-105"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Select PDF Forms
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Processing Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileInput className="h-5 w-5" />
                Auto-Fill Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your form auto-fill tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {formTypes[job.formType as keyof typeof formTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.fieldsDetected && (
                            <span>{job.fieldsDetected} fields detected</span>
                          )}
                          {job.fieldsFilled && (
                            <span className="text-green-600">{job.fieldsFilled} fields filled</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            link.download = `filled-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.pdf`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Filled form downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'analyzing' || job.status === 'filling') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading form...'}
                          {job.status === 'analyzing' && 'Analyzing form fields...'}
                          {job.status === 'filling' && 'Filling form fields...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Auto-Fill Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Features Sidebar */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Key Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Brain className="h-4 w-4 text-blue-500" />
                <span>AI field detection</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Instant form filling</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <FileCheck className="h-4 w-4 text-green-500" />
                <span>Data validation</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Processing Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Personal forms:</span>
                <span className="text-muted-foreground">5-12 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Business forms:</span>
                <span className="text-muted-foreground">8-15 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Financial forms:</span>
                <span className="text-muted-foreground">10-18 seconds</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm">• Encrypted data storage</div>
              <div className="text-sm">• Secure form processing</div>
              <div className="text-sm">• No data retention</div>
              <div className="text-sm">• Privacy compliant</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TooltipProvider>
  );
}