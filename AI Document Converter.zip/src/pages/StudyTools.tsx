import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  GraduationCap, 
  Download,
  FileText,
  BookOpen,
  HelpCircle,
  Zap,
  Brain,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Clock,
  Target,
  Lightbulb,
  Network,
  List,
  Users
} from 'lucide-react';
import { toast } from 'sonner';

interface StudyJob {
  id: string;
  fileName: string;
  fileSize: number;
  studyType: string;
  status: 'uploading' | 'analyzing' | 'generating' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  settings?: any;
}

const studyTypes = {
  notes: {
    title: 'PDF → Notes',
    icon: BookOpen,
    color: 'bg-blue-500',
    description: 'Convert PDF content into structured study notes',
    formats: ['Outline Format', 'Cornell Notes', 'Bullet Points', 'Summary Format'],
    options: {
      detail: { min: 1, max: 5, default: 3, label: 'Detail Level' },
      sections: { min: 3, max: 20, default: 10, label: 'Number of Sections' }
    }
  },
  mcqs: {
    title: 'PDF → MCQs',
    icon: HelpCircle,
    color: 'bg-green-500',
    description: 'Generate multiple choice questions from PDF content',
    formats: ['Easy Level', 'Medium Level', 'Hard Level', 'Mixed Difficulty'],
    options: {
      count: { min: 5, max: 50, default: 20, label: 'Number of Questions' },
      choices: { min: 2, max: 6, default: 4, label: 'Answer Choices' }
    }
  },
  flashcards: {
    title: 'PDF → Flashcards',
    icon: Zap,
    color: 'bg-purple-500',
    description: 'Create interactive flashcards for memorization',
    formats: ['Question-Answer', 'Term-Definition', 'Concept-Explanation', 'Fill-in-Blanks'],
    options: {
      count: { min: 10, max: 100, default: 30, label: 'Number of Cards' },
      difficulty: { min: 1, max: 5, default: 3, label: 'Difficulty Level' }
    }
  },
  mindmap: {
    title: 'PDF → Mindmap',
    icon: Network,
    color: 'bg-orange-500',
    description: 'Generate visual mindmaps from document structure',
    formats: ['Hierarchical', 'Radial', 'Flowchart', 'Concept Map'],
    options: {
      branches: { min: 3, max: 15, default: 8, label: 'Main Branches' },
      depth: { min: 2, max: 5, default: 3, label: 'Depth Levels' }
    }
  }
};

const studyLevels = [
  { id: 'beginner', name: 'Beginner', description: 'Basic concepts and fundamentals' },
  { id: 'intermediate', name: 'Intermediate', description: 'Moderate complexity with examples' },
  { id: 'advanced', name: 'Advanced', description: 'Complex analysis and critical thinking' },
  { id: 'expert', name: 'Expert', description: 'Professional level with deep insights' }
];

export default function StudyTools() {
  const [jobs, setJobs] = useState<StudyJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [studySettings, setStudySettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for study tools'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, studyType: string): number => {
    const baseTime = {
      'notes': 10,
      'mcqs': 15,
      'flashcards': 12,
      'mindmap': 8
    }[studyType] || 10;

    const sizeTime = Math.ceil(fileSize / (2 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, studyType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, studyType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, studyType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, studyType);
  };

  const handleFiles = (files: File[], studyType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(prev => ({
      ...prev,
      [studyType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, studyType);
      
      const newJob: StudyJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        studyType,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        settings: studySettings[studyType] || {}
      };

      setJobs(prev => [...prev, newJob]);
      simulateStudyGeneration(jobId, estimatedTime, studyType);
    });

    toast.success(`Started ${studyTypes[studyType as keyof typeof studyTypes].title} generation for ${validFiles.length} file(s)`);
  };

  const simulateStudyGeneration = (jobId: string, estimatedTime: number, studyType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (15% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 150;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 12 + 3;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'analyzing', progress: 0 }
            : job
        ));

        // Simulate AI analysis (30% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'generating', progress: 0 }
              : job
          ));

          // Simulate generation (55% of total time)
          const generationDuration = estimatedTime * 550;
          const generationInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 5 + 1;
                if (newProgress >= 100) {
                  clearInterval(generationInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate result based on study type
                  const result = generateStudyResult(studyType, job.settings);
                  const downloadBlob = createStudyFile(studyType, job.fileName, result, job.settings);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result: getResultSummary(studyType, job.settings)
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, generationDuration / 50);
        }, estimatedTime * 300);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateStudyResult = (studyType: string, settings: any): string => {
    switch (studyType) {
      case 'notes':
        return generateNotes(settings);
      case 'mcqs':
        return generateMCQs(settings);
      case 'flashcards':
        return generateFlashcards(settings);
      case 'mindmap':
        return generateMindmap(settings);
      default:
        return 'Study material generated successfully';
    }
  };

  const generateNotes = (settings: any): string => {
    const format = settings?.format || 'Outline Format';
    const sections = settings?.sections || 10;
    
    let notes = `# Study Notes - ${format}\n\n`;
    
    for (let i = 1; i <= Math.min(sections, 5); i++) {
      notes += `## Section ${i}: Key Concepts\n\n`;
      notes += `- Important point ${i}.1\n`;
      notes += `- Important point ${i}.2\n`;
      notes += `- Important point ${i}.3\n\n`;
      notes += `### Summary\n`;
      notes += `Brief summary of section ${i} concepts and their applications.\n\n`;
    }
    
    return notes;
  };

  const generateMCQs = (settings: any): string => {
    const count = settings?.count || 20;
    const choices = settings?.choices || 4;
    
    let mcqs = `# Multiple Choice Questions\n\n`;
    
    for (let i = 1; i <= Math.min(count, 10); i++) {
      mcqs += `**Question ${i}:** What is the main concept discussed in this section?\n\n`;
      
      for (let j = 1; j <= choices; j++) {
        const letter = String.fromCharCode(64 + j);
        mcqs += `${letter}) Option ${j} - Sample answer choice\n`;
      }
      
      mcqs += `\n**Correct Answer:** A\n`;
      mcqs += `**Explanation:** This is the correct answer because...\n\n`;
      mcqs += `---\n\n`;
    }
    
    return mcqs;
  };

  const generateFlashcards = (settings: any): string => {
    const count = settings?.count || 30;
    const format = settings?.format || 'Question-Answer';
    
    let flashcards = `# Flashcards - ${format}\n\n`;
    
    for (let i = 1; i <= Math.min(count, 15); i++) {
      flashcards += `## Card ${i}\n\n`;
      flashcards += `**Front:** Key concept or question ${i}\n\n`;
      flashcards += `**Back:** Detailed explanation and answer for concept ${i}\n\n`;
      flashcards += `**Tags:** #important #concept${i} #study\n\n`;
      flashcards += `---\n\n`;
    }
    
    return flashcards;
  };

  const generateMindmap = (settings: any): string => {
    const branches = settings?.branches || 8;
    const format = settings?.format || 'Hierarchical';
    
    let mindmap = `# Mindmap - ${format}\n\n`;
    mindmap += `## Central Topic: Document Main Theme\n\n`;
    
    for (let i = 1; i <= Math.min(branches, 6); i++) {
      mindmap += `### Branch ${i}: Key Area ${i}\n`;
      mindmap += `- Sub-concept ${i}.1\n`;
      mindmap += `- Sub-concept ${i}.2\n`;
      mindmap += `- Sub-concept ${i}.3\n\n`;
    }
    
    return mindmap;
  };

  const createStudyFile = (studyType: string, fileName: string, content: string, settings: any): Blob => {
    switch (studyType) {
      case 'notes':
        return new Blob([content], { type: 'text/markdown' });
      case 'mcqs':
        return new Blob([content], { type: 'text/markdown' });
      case 'flashcards':
        // Create Anki-compatible format
        const ankiContent = content.replace(/\*\*Front:\*\* (.*?)\n\n\*\*Back:\*\* (.*?)\n\n/g, '$1\t$2\n');
        return new Blob([ankiContent], { type: 'text/plain' });
      case 'mindmap':
        return new Blob([content], { type: 'text/markdown' });
      default:
        return new Blob([content], { type: 'text/plain' });
    }
  };

  const getResultSummary = (studyType: string, settings: any): string => {
    switch (studyType) {
      case 'notes':
        return `Generated ${settings?.sections || 10} sections of structured study notes in ${settings?.format || 'Outline Format'} format.`;
      case 'mcqs':
        return `Created ${settings?.count || 20} multiple choice questions with ${settings?.choices || 4} answer choices each.`;
      case 'flashcards':
        return `Generated ${settings?.count || 30} flashcards in ${settings?.format || 'Question-Answer'} format, ready for Anki import.`;
      case 'mindmap':
        return `Created visual mindmap with ${settings?.branches || 8} main branches in ${settings?.format || 'Hierarchical'} layout.`;
      default:
        return 'Study material generated successfully';
    }
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateStudyGeneration(jobId, job.estimatedTime || 10, job.studyType);
    }
  };

  const getStatusIcon = (status: StudyJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'analyzing':
        return <Brain className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'generating':
        return <Lightbulb className="h-4 w-4 animate-pulse text-yellow-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: StudyJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'analyzing':
        return 'Analyzing Content...';
      case 'generating':
        return 'Generating Study Material...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const getFileExtension = (studyType: string): string => {
    switch (studyType) {
      case 'notes':
        return 'md';
      case 'mcqs':
        return 'md';
      case 'flashcards':
        return 'txt';
      case 'mindmap':
        return 'md';
      default:
        return 'txt';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary floating" />
            AI Study Tools
          </h1>
          <p className="text-muted-foreground">
            Transform your PDFs into interactive study materials with AI
          </p>
        </div>

        <Tabs defaultValue="notes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="notes" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Notes
            </TabsTrigger>
            <TabsTrigger value="mcqs" className="flex items-center gap-2">
              <HelpCircle className="h-4 w-4" />
              MCQs
            </TabsTrigger>
            <TabsTrigger value="flashcards" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Flashcards
            </TabsTrigger>
            <TabsTrigger value="mindmap" className="flex items-center gap-2">
              <Network className="h-4 w-4" />
              Mindmap
            </TabsTrigger>
          </TabsList>

          {Object.entries(studyTypes).map(([key, type]) => (
            <TabsContent key={key} value={key} className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card className="conversion-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <type.icon className="h-5 w-5" />
                        {type.title}
                      </CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Format Selection */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Output Format:</h4>
                        <div className="grid grid-cols-2 gap-3">
                          {type.formats.map((format) => (
                            <Button
                              key={format}
                              variant={studySettings[key]?.format === format ? "default" : "outline"}
                              className="justify-start h-auto p-3"
                              onClick={() => setStudySettings(prev => ({
                                ...prev,
                                [key]: { ...prev[key], format }
                              }))}
                            >
                              <span className="text-sm">{format}</span>
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* Settings Sliders */}
                      <div className="space-y-6">
                        {Object.entries(type.options).map(([optionKey, option]) => (
                          <div key={optionKey} className="space-y-2">
                            <div className="flex justify-between">
                              <label className="text-sm font-medium">{option.label}</label>
                              <span className="text-sm text-muted-foreground">
                                {studySettings[key]?.[optionKey] || option.default}
                              </span>
                            </div>
                            <Slider
                              value={[studySettings[key]?.[optionKey] || option.default]}
                              onValueChange={(value) => setStudySettings(prev => ({
                                ...prev,
                                [key]: { ...prev[key], [optionKey]: value[0] }
                              }))}
                              max={option.max}
                              min={option.min}
                              step={1}
                              className="w-full"
                            />
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>{option.min}</span>
                              <span>{option.max}</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Study Level */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Study Level:</h4>
                        <Select
                          value={studySettings[key]?.level || 'intermediate'}
                          onValueChange={(value) => setStudySettings(prev => ({
                            ...prev,
                            [key]: { ...prev[key], level: value }
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select study level" />
                          </SelectTrigger>
                          <SelectContent>
                            {studyLevels.map((level) => (
                              <SelectItem key={level.id} value={level.id}>
                                <div>
                                  <div className="font-medium">{level.name}</div>
                                  <div className="text-xs text-muted-foreground">{level.description}</div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* File Preview */}
                      {selectedFiles[key]?.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(key)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {selectedFiles[key].slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {selectedFiles[key].length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{selectedFiles[key].length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      {/* Upload Area */}
                      <div
                        className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, key)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, key)}
                      >
                        <div className="floating">
                          <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <h3 className="font-semibold mb-2">Upload PDF for {type.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Drag & drop your PDF files here or click to browse
                        </p>
                        <input
                          ref={el => fileInputRefs.current[key] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${key}`}
                          accept=".pdf"
                          onChange={(e) => handleFileSelect(e, key)}
                        />
                        <Button 
                          variant="outline"
                          onClick={() => document.getElementById(`file-${key}`)?.click()}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Select PDF Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {key === 'notes' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <List className="h-4 w-4 text-blue-500" />
                            <span>Structured formatting</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Brain className="h-4 w-4 text-purple-500" />
                            <span>Key concept extraction</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <FileText className="h-4 w-4 text-green-500" />
                            <span>Multiple note formats</span>
                          </div>
                        </>
                      )}
                      {key === 'mcqs' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <HelpCircle className="h-4 w-4 text-blue-500" />
                            <span>Auto-generated questions</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-green-500" />
                            <span>Multiple difficulty levels</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-purple-500" />
                            <span>Answer explanations</span>
                          </div>
                        </>
                      )}
                      {key === 'flashcards' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-yellow-500" />
                            <span>Anki-compatible format</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Brain className="h-4 w-4 text-blue-500" />
                            <span>Spaced repetition ready</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="h-4 w-4 text-green-500" />
                            <span>Shareable card decks</span>
                          </div>
                        </>
                      )}
                      {key === 'mindmap' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Network className="h-4 w-4 text-purple-500" />
                            <span>Visual concept mapping</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-blue-500" />
                            <span>Hierarchical structure</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Lightbulb className="h-4 w-4 text-yellow-500" />
                            <span>Concept relationships</span>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        Generation Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Small PDFs:</span>
                        <span className="text-muted-foreground">8-15 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Medium PDFs:</span>
                        <span className="text-muted-foreground">15-30 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Large PDFs:</span>
                        <span className="text-muted-foreground">30-60 seconds</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Study Generation Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5" />
                Study Material Generation
              </CardTitle>
              <CardDescription>
                Track the progress of your study material generation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {studyTypes[job.studyType as keyof typeof studyTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            const studyName = studyTypes[job.studyType as keyof typeof studyTypes]?.title.toLowerCase().replace(/\s+/g, '-');
                            const extension = getFileExtension(job.studyType);
                            link.download = `${studyName}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${extension}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Study material downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'analyzing' || job.status === 'generating') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'analyzing' && 'Analyzing content...'}
                          {job.status === 'generating' && 'Generating study material...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Generation Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}