import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  Brain, 
  Download,
  FileText,
  Languages,
  Database,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Clock,
  Target,
  Globe,
  Table,
  Hash,
  Image,
  Mail,
  Calculator
} from 'lucide-react';
import { toast } from 'sonner';

interface AnalysisJob {
  id: string;
  fileName: string;
  fileSize: number;
  analysisType: string;
  status: 'uploading' | 'analyzing' | 'processing' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  settings?: any;
}

const analysisTypes = {
  summarizer: {
    title: 'AI Summarizer',
    icon: Brain,
    color: 'bg-blue-500',
    description: 'Generate intelligent summaries of your PDF content',
    options: [
      { id: 'short', name: 'Short Summary', description: '2-3 sentences overview' },
      { id: 'detailed', name: 'Detailed Summary', description: 'Comprehensive analysis' },
      { id: 'pagewise', name: 'Page-wise Summary', description: 'Summary for each page' },
      { id: 'keypoints', name: 'Key Points & Insights', description: 'Bullet points and insights' }
    ]
  },
  translator: {
    title: 'AI Translation',
    icon: Languages,
    color: 'bg-green-500',
    description: 'Translate entire PDF while preserving layout',
    options: [
      { id: 'en-hi', name: 'English to Hindi', description: 'Translate to Hindi' },
      { id: 'hi-en', name: 'Hindi to English', description: 'Translate to English' },
      { id: 'en-ta', name: 'English to Tamil', description: 'Translate to Tamil' },
      { id: 'en-te', name: 'English to Telugu', description: 'Translate to Telugu' },
      { id: 'en-bn', name: 'English to Bengali', description: 'Translate to Bengali' },
      { id: 'en-gu', name: 'English to Gujarati', description: 'Translate to Gujarati' },
      { id: 'en-mr', name: 'English to Marathi', description: 'Translate to Marathi' },
      { id: 'en-kn', name: 'English to Kannada', description: 'Translate to Kannada' }
    ]
  },
  extractor: {
    title: 'Data Extraction',
    icon: Database,
    color: 'bg-purple-500',
    description: 'Extract specific data types from your PDF',
    options: [
      { id: 'tables', name: 'Extract Tables', description: 'All tables as CSV/Excel', icon: Table },
      { id: 'numbers', name: 'Numerical Data', description: 'Numbers, statistics, metrics', icon: Hash },
      { id: 'images', name: 'Extract Images', description: 'All images in high quality', icon: Image },
      { id: 'contacts', name: 'Emails & Phones', description: 'Contact information', icon: Mail },
      { id: 'equations', name: 'Extract Equations', description: 'Mathematical formulas', icon: Calculator },
      { id: 'headings', name: 'Extract Headings', description: 'Document structure', icon: FileText }
    ]
  }
};

const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', flag: '🇧🇩' },
  { code: 'gu', name: 'Gujarati', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', flag: '🇮🇳' },
  { code: 'or', name: 'Odia', flag: '🇮🇳' }
];

export default function AIAnalysis() {
  const [jobs, setJobs] = useState<AnalysisJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [analysisSettings, setAnalysisSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for AI analysis'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, analysisType: string): number => {
    const baseTime = {
      'summarizer': 8,
      'translator': 15,
      'extractor': 10
    }[analysisType] || 8;

    const sizeTime = Math.ceil(fileSize / (3 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, analysisType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, analysisType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, analysisType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, analysisType);
  };

  const handleFiles = (files: File[], analysisType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(prev => ({
      ...prev,
      [analysisType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, analysisType);
      
      const newJob: AnalysisJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        analysisType,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        settings: analysisSettings[analysisType] || {}
      };

      setJobs(prev => [...prev, newJob]);
      simulateAnalysis(jobId, estimatedTime, analysisType);
    });

    toast.success(`Started ${analysisTypes[analysisType as keyof typeof analysisTypes].title} for ${validFiles.length} file(s)`);
  };

  const simulateAnalysis = (jobId: string, estimatedTime: number, analysisType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (15% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 150;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 12 + 3;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'analyzing', progress: 0 }
            : job
        ));

        // Simulate AI analysis (25% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'processing', progress: 0 }
              : job
          ));

          // Simulate processing (60% of total time)
          const processingDuration = estimatedTime * 600;
          const processingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 6 + 2;
                if (newProgress >= 100) {
                  clearInterval(processingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate result based on analysis type
                  let result = '';
                  let downloadBlob: Blob;
                  
                  switch (analysisType) {
                    case 'summarizer':
                      result = generateSummaryResult(job.settings?.option || 'short');
                      downloadBlob = new Blob([result], { type: 'text/plain' });
                      break;
                    case 'translator':
                      result = generateTranslationResult(job.settings?.targetLanguage || 'hi');
                      downloadBlob = downloadUtils.createPDF(job.fileName, `Translated document to ${job.settings?.targetLanguage || 'Hindi'}`);
                      break;
                    case 'extractor':
                      result = generateExtractionResult(job.settings?.extractType || 'tables');
                      downloadBlob = job.settings?.extractType === 'tables' 
                        ? downloadUtils.createExcel(job.fileName)
                        : new Blob([result], { type: 'text/plain' });
                      break;
                    default:
                      result = 'Analysis completed successfully';
                      downloadBlob = new Blob([result], { type: 'text/plain' });
                  }
                  
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, processingDuration / 50);
        }, estimatedTime * 250);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateSummaryResult = (option: string): string => {
    const summaries = {
      short: 'This document contains important information about business processes and procedures. It outlines key strategies and recommendations for implementation.',
      detailed: 'This comprehensive document provides detailed analysis of business operations, including strategic recommendations, process improvements, and implementation guidelines. The content covers multiple aspects of organizational development and operational efficiency.',
      pagewise: 'Page 1: Introduction and overview\nPage 2: Main content and analysis\nPage 3: Recommendations and conclusions\nPage 4: Appendices and references',
      keypoints: '• Key strategic initiatives identified\n• Process improvement opportunities highlighted\n• Implementation timeline established\n• Resource requirements outlined\n• Success metrics defined'
    };
    return summaries[option as keyof typeof summaries] || summaries.short;
  };

  const generateTranslationResult = (targetLang: string): string => {
    const lang = languages.find(l => l.code === targetLang)?.name || 'Hindi';
    return `Document successfully translated to ${lang}. Layout and formatting preserved.`;
  };

  const generateExtractionResult = (extractType: string): string => {
    const results = {
      tables: 'Found 3 tables with 45 rows of data. Exported to Excel format.',
      numbers: 'Extracted 127 numerical values including statistics, percentages, and measurements.',
      images: 'Found 8 images. All images extracted in original quality.',
      contacts: 'Extracted 12 email addresses and 8 phone numbers.',
      equations: 'Found 5 mathematical equations and formulas.',
      headings: 'Extracted document structure with 15 headings and subheadings.'
    };
    return results[extractType as keyof typeof results] || 'Data extraction completed.';
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateAnalysis(jobId, job.estimatedTime || 8, job.analysisType);
    }
  };

  const getStatusIcon = (status: AnalysisJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'analyzing':
        return <Brain className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'processing':
        return <RefreshCw className="h-4 w-4 animate-spin text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: AnalysisJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'analyzing':
        return 'AI Analyzing...';
      case 'processing':
        return 'Processing...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary floating" />
            AI Analysis Tools
          </h1>
          <p className="text-muted-foreground">
            Advanced AI-powered analysis, translation, and data extraction for your PDFs
          </p>
        </div>

        <Tabs defaultValue="summarizer" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="summarizer" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Summarizer
            </TabsTrigger>
            <TabsTrigger value="translator" className="flex items-center gap-2">
              <Languages className="h-4 w-4" />
              Translation
            </TabsTrigger>
            <TabsTrigger value="extractor" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              Data Extraction
            </TabsTrigger>
          </TabsList>

          {Object.entries(analysisTypes).map(([key, type]) => (
            <TabsContent key={key} value={key} className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card className="conversion-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <type.icon className="h-5 w-5" />
                        {type.title}
                      </CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Analysis Options */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Analysis Options:</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {type.options.map((option) => {
                            const OptionIcon = option.icon;
                            return (
                              <Button
                                key={option.id}
                                variant={analysisSettings[key]?.option === option.id ? "default" : "outline"}
                                className="justify-start h-auto p-4"
                                onClick={() => setAnalysisSettings(prev => ({
                                  ...prev,
                                  [key]: { ...prev[key], option: option.id }
                                }))}
                              >
                                <div className="text-left">
                                  <div className="flex items-center gap-2 mb-1">
                                    {OptionIcon && <OptionIcon className="h-4 w-4" />}
                                    <span className="font-medium">{option.name}</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground">{option.description}</p>
                                </div>
                              </Button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Special Settings for Translation */}
                      {key === 'translator' && (
                        <div className="space-y-4">
                          <h4 className="font-medium">Target Language:</h4>
                          <Select
                            value={analysisSettings[key]?.targetLanguage || 'hi'}
                            onValueChange={(value) => setAnalysisSettings(prev => ({
                              ...prev,
                              [key]: { ...prev[key], targetLanguage: value }
                            }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select target language" />
                            </SelectTrigger>
                            <SelectContent>
                              {languages.map((lang) => (
                                <SelectItem key={lang.code} value={lang.code}>
                                  <span className="flex items-center gap-2">
                                    <span>{lang.flag}</span>
                                    <span>{lang.name}</span>
                                  </span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      {/* File Preview */}
                      {selectedFiles[key]?.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(key)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {selectedFiles[key].slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {selectedFiles[key].length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{selectedFiles[key].length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      {/* Upload Area */}
                      <div
                        className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, key)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, key)}
                      >
                        <div className="floating">
                          <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <h3 className="font-semibold mb-2">Upload PDF for {type.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Drag & drop your PDF files here or click to browse
                        </p>
                        <input
                          ref={el => fileInputRefs.current[key] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${key}`}
                          accept=".pdf"
                          onChange={(e) => handleFileSelect(e, key)}
                        />
                        <Button 
                          variant="outline"
                          onClick={() => document.getElementById(`file-${key}`)?.click()}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Select PDF Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar with capabilities */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Capabilities
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {key === 'summarizer' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-yellow-500" />
                            <span>Intelligent content analysis</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Target className="h-4 w-4 text-blue-500" />
                            <span>Key insights extraction</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="h-4 w-4 text-green-500" />
                            <span>Multiple summary formats</span>
                          </div>
                        </>
                      )}
                      {key === 'translator' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Globe className="h-4 w-4 text-blue-500" />
                            <span>10+ Indian languages</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <FileText className="h-4 w-4 text-green-500" />
                            <span>Layout preservation</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Brain className="h-4 w-4 text-purple-500" />
                            <span>Context-aware translation</span>
                          </div>
                        </>
                      )}
                      {key === 'extractor' && (
                        <>
                          <div className="flex items-center gap-2 text-sm">
                            <Table className="h-4 w-4 text-blue-500" />
                            <span>Table extraction</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Image className="h-4 w-4 text-green-500" />
                            <span>Image extraction</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-4 w-4 text-orange-500" />
                            <span>Contact information</span>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        Processing Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Small files (&lt;5MB):</span>
                        <span className="text-muted-foreground">5-10 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Medium files (5-20MB):</span>
                        <span className="text-muted-foreground">10-25 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Large files (20-50MB):</span>
                        <span className="text-muted-foreground">25-60 seconds</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Analysis Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Analysis Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your AI analysis tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {analysisTypes[job.analysisType as keyof typeof analysisTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            const analysisName = analysisTypes[job.analysisType as keyof typeof analysisTypes]?.title.toLowerCase().replace(/\s+/g, '-');
                            link.download = `${analysisName}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${job.analysisType === 'extractor' && job.settings?.extractType === 'tables' ? 'xlsx' : job.analysisType === 'translator' ? 'pdf' : 'txt'}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Analysis result downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'analyzing' || job.status === 'processing') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'analyzing' && 'AI analyzing content...'}
                          {job.status === 'processing' && 'Processing results...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Analysis Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}