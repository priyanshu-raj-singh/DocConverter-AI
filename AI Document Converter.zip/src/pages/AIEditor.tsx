import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  Wand2, 
  Download,
  FileText,
  Sparkles,
  MessageSquare,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  Lightbulb,
  Zap,
  Clock,
  FileCheck,
  Brain,
  Target,
  Cpu
} from 'lucide-react';
import { toast } from 'sonner';

interface AIEditJob {
  id: string;
  fileName: string;
  fileSize: number;
  prompt: string;
  status: 'uploading' | 'analyzing' | 'processing' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  preview?: string;
  estimatedTime?: number;
  actualTime?: number;
  confidence?: number;
}

const promptCategories = {
  text: {
    title: 'Text Operations',
    icon: FileText,
    color: 'bg-blue-500',
    prompts: [
      "Remove all watermarks from this PDF",
      "Change the title on the first page to 'Annual Report 2024'",
      "Convert all text to uppercase",
      "Remove all footnotes and references",
      "Replace all instances of 'Company Name' with 'New Corp'"
    ]
  },
  translation: {
    title: 'Translation & Language',
    icon: MessageSquare,
    color: 'bg-green-500',
    prompts: [
      "Translate this document to Spanish",
      "Translate to French while preserving formatting",
      "Convert to simplified Chinese",
      "Translate technical terms to German"
    ]
  },
  analysis: {
    title: 'Analysis & Extraction',
    icon: Brain,
    color: 'bg-purple-500',
    prompts: [
      "Summarize this PDF in 3 paragraphs",
      "Extract all tables and convert to CSV format",
      "Extract all numerical data and statistics",
      "Create a bullet-point summary of key findings",
      "Extract all contact information"
    ]
  },
  structure: {
    title: 'Structure & Layout',
    icon: Target,
    color: 'bg-orange-500',
    prompts: [
      "Remove page 3 from this document",
      "Split this PDF into separate chapters",
      "Merge this with another PDF document",
      "Reorder pages: move page 5 to position 2",
      "Extract pages 10-20 into a new document"
    ]
  },
  enhancement: {
    title: 'Enhancement & Cleanup',
    icon: Sparkles,
    color: 'bg-pink-500',
    prompts: [
      "Enhance image quality and contrast",
      "Remove background noise from scanned pages",
      "Straighten skewed pages",
      "Remove blank pages",
      "Optimize for smaller file size"
    ]
  }
};

const aiCapabilities = [
  {
    icon: FileText,
    title: 'Text Processing',
    description: 'Advanced OCR, text extraction, and modification',
    accuracy: 98
  },
  {
    icon: MessageSquare,
    title: 'Language Translation',
    description: 'Support for 100+ languages with context awareness',
    accuracy: 95
  },
  {
    icon: Brain,
    title: 'Content Analysis',
    description: 'Intelligent summarization and data extraction',
    accuracy: 92
  },
  {
    icon: Target,
    title: 'Structure Manipulation',
    description: 'Page management and document restructuring',
    accuracy: 99
  },
  {
    icon: Sparkles,
    title: 'Image Enhancement',
    description: 'AI-powered image processing and optimization',
    accuracy: 88
  },
  {
    icon: Cpu,
    title: 'Smart Processing',
    description: 'Context-aware document understanding',
    accuracy: 94
  }
];

export default function AIEditor() {
  const [jobs, setJobs] = useState<AIEditJob[]>([]);
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [promptCategory, setPromptCategory] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for AI editing'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit for AI processing'
      };
    }

    return { valid: true };
  };

  const estimateAIProcessingTime = (fileSize: number, prompt: string): number => {
    let baseTime = 5; // Base AI processing time
    
    // Adjust based on operation complexity
    if (prompt.toLowerCase().includes('translate')) baseTime += 8;
    if (prompt.toLowerCase().includes('summarize')) baseTime += 6;
    if (prompt.toLowerCase().includes('extract')) baseTime += 4;
    if (prompt.toLowerCase().includes('enhance')) baseTime += 10;
    
    // Add time based on file size (1 second per 2MB)
    const sizeTime = Math.ceil(fileSize / (2 * 1024 * 1024));
    
    return baseTime + sizeTime;
  };

  const calculateConfidence = (prompt: string): number => {
    let confidence = 85; // Base confidence
    
    // Adjust based on operation type
    if (prompt.toLowerCase().includes('remove')) confidence += 10;
    if (prompt.toLowerCase().includes('translate')) confidence += 5;
    if (prompt.toLowerCase().includes('extract')) confidence += 8;
    if (prompt.toLowerCase().includes('enhance')) confidence -= 5;
    if (prompt.toLowerCase().includes('complex') || prompt.toLowerCase().includes('advanced')) confidence -= 10;
    
    return Math.min(Math.max(confidence, 70), 99);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0 && currentPrompt.trim()) {
      handleFiles(files);
    } else if (!currentPrompt.trim()) {
      toast.error('Please enter a prompt first');
    }
  }, [currentPrompt]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0 && currentPrompt.trim()) {
      handleFiles(files);
    } else if (!currentPrompt.trim()) {
      toast.error('Please enter a prompt first');
    }
  };

  const handleFiles = (files: File[]) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(validFiles);

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateAIProcessingTime(file.size, currentPrompt);
      const confidence = calculateConfidence(currentPrompt);
      
      const newJob: AIEditJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        prompt: currentPrompt,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        confidence
      };

      setJobs(prev => [...prev, newJob]);
      simulateAIProcessing(jobId, estimatedTime);
    });

    toast.success(`Started AI processing for ${validFiles.length} file(s)`);
    setCurrentPrompt('');
    setSelectedFiles([]);
  };

  const simulateAIProcessing = (jobId: string, estimatedTime: number) => {
    const startTime = Date.now();
    
    // Simulate upload progress (15% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 150;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 12 + 3;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'analyzing', progress: 0 }
            : job
        ));

        // Simulate AI analysis (25% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'processing', progress: 0 }
              : job
          ));

          // Simulate AI processing (60% of total time)
          const processingDuration = estimatedTime * 600;
          const processingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 6 + 2;
                if (newProgress >= 100) {
                  clearInterval(processingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Create AI-edited PDF for download
                  const aiEditedBlob = downloadUtils.createAIEditedPDF(job.fileName, job.prompt);
                  const downloadUrl = URL.createObjectURL(aiEditedBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    preview: `AI processing completed successfully in ${actualTime}s. The document has been modified according to your prompt with ${job.confidence}% confidence.`
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, processingDuration / 50);
        }, estimatedTime * 250);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateAIProcessing(jobId, job.estimatedTime || 5);
    }
  };

  const clearFiles = () => {
    setSelectedFiles([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getStatusIcon = (status: AIEditJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'analyzing':
        return <Brain className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'processing':
        return <Cpu className="h-4 w-4 animate-spin text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: AIEditJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'analyzing':
        return 'AI Analyzing...';
      case 'processing':
        return 'AI Processing...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Wand2 className="h-8 w-8 text-primary floating" />
            AI PDF Editor
          </h1>
          <p className="text-muted-foreground">
            Edit your PDFs using advanced AI with natural language prompts
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Editor */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  What would you like to do?
                </CardTitle>
                <CardDescription>
                  Describe what you want to change in your PDF using natural language
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Textarea
                    placeholder="e.g., Remove the watermark on all pages, translate to Spanish, extract all tables..."
                    value={currentPrompt}
                    onChange={(e) => setCurrentPrompt(e.target.value)}
                    className="min-h-[120px] pr-12"
                  />
                  {currentPrompt && (
                    <div className="absolute top-2 right-2">
                      <Tooltip>
                        <TooltipTrigger>
                          <div className="flex items-center gap-1 text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            <Zap className="h-3 w-3" />
                            {calculateConfidence(currentPrompt)}%
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>AI Confidence Level</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  )}
                </div>
                
                {/* Prompt Categories */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Quick Prompts:</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {Object.entries(promptCategories).map(([key, category]) => {
                      const Icon = category.icon;
                      return (
                        <Button
                          key={key}
                          variant={promptCategory === key ? "default" : "outline"}
                          size="sm"
                          className="justify-start h-auto p-3"
                          onClick={() => setPromptCategory(promptCategory === key ? null : key)}
                        >
                          <div className={`h-6 w-6 rounded ${category.color} flex items-center justify-center mr-2`}>
                            <Icon className="h-3 w-3 text-white" />
                          </div>
                          <span className="text-xs">{category.title}</span>
                        </Button>
                      );
                    })}
                  </div>
                  
                  {promptCategory && (
                    <div className="space-y-2 p-3 bg-muted/50 rounded-lg bounce-in">
                      <h4 className="text-sm font-medium">{promptCategories[promptCategory as keyof typeof promptCategories].title}</h4>
                      <div className="flex flex-wrap gap-1">
                        {promptCategories[promptCategory as keyof typeof promptCategories].prompts.map((prompt, index) => (
                          <Button
                            key={index}
                            variant="ghost"
                            size="sm"
                            onClick={() => setCurrentPrompt(prompt)}
                            className="text-xs h-auto p-2 hover:bg-primary/10"
                          >
                            {prompt}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Upload Your PDF
                </CardTitle>
                <CardDescription>
                  Upload the PDF file you want to edit with AI (Max 50MB)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* File Preview */}
                {selectedFiles.length > 0 && (
                  <div className="mb-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Selected Files:</span>
                      <Button variant="ghost" size="sm" onClick={clearFiles}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="file-preview">
                        <div className="flex items-center gap-2">
                          <FileCheck className="h-4 w-4 text-green-500" />
                          <span className="text-sm truncate flex-1">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatFileSize(file.size)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div
                  className={`upload-area ${dragOver ? 'dragover' : ''} ${!currentPrompt.trim() ? 'opacity-50' : ''}`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  <div className="flex flex-col items-center">
                    <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mb-4 floating">
                      <FileText className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold mb-2">Drop your PDF here</h3>
                    <p className="text-sm text-muted-foreground mb-4 text-center">
                      {currentPrompt.trim() 
                        ? 'Drag & drop your PDF file here or click to browse'
                        : 'Please enter a prompt first, then upload your PDF'
                      }
                    </p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      className="hidden"
                      id="pdf-upload"
                      accept=".pdf"
                      onChange={handleFileSelect}
                      disabled={!currentPrompt.trim()}
                    />
                    <Button 
                      variant="outline"
                      onClick={() => {
                        const input = document.getElementById('pdf-upload') as HTMLInputElement;
                        if (input) {
                          input.click();
                        } else {
                          console.error('PDF upload input not found');
                          toast.error('File input not available. Please refresh the page.');
                        }
                      }}
                      disabled={!currentPrompt.trim()}
                      className="transition-all duration-200 hover:scale-105"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Select PDF Files
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Sidebar */}
          <div className="space-y-6">
            <Card className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  AI Capabilities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {aiCapabilities.map((capability, index) => {
                  const Icon = capability.icon;
                  return (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-medium text-sm">{capability.title}</p>
                          <Badge variant="secondary" className="text-xs">
                            {capability.accuracy}%
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{capability.description}</p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Processing Info
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Text Operations:</span>
                  <span className="text-muted-foreground">2-5 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Translation:</span>
                  <span className="text-muted-foreground">5-15 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Analysis:</span>
                  <span className="text-muted-foreground">3-10 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Enhancement:</span>
                  <span className="text-muted-foreground">8-20 seconds</span>
                </div>
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Processing time varies based on file size and complexity
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Enhanced AI Processing Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                AI Processing Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your AI-powered PDF edits with detailed insights
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                          {job.confidence && (
                            <Badge variant="outline" className="text-xs">
                              {job.confidence}% confidence
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl;
                            link.download = `ai-edited-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.pdf`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('AI-edited PDF downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-muted/50 rounded p-3">
                    <p className="text-sm font-medium mb-1">AI Prompt:</p>
                    <p className="text-sm text-muted-foreground">{job.prompt}</p>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'analyzing' || job.status === 'processing') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'analyzing' && 'AI analyzing content...'}
                          {job.status === 'processing' && 'AI processing changes...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.preview && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <p className="text-sm text-green-800 dark:text-green-200">{job.preview}</p>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}