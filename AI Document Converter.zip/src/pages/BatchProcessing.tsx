import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Layers, Upload, Download, FileText, CheckCircle, Clock, Target, Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function BatchProcessing() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
    toast.success(`Selected ${files.length} file(s) for batch processing`);
  };

  return (
    <div className="container py-8">
      <div className="mb-8 slide-up">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Layers className="h-8 w-8 text-primary floating" />
          Batch Processing
        </h1>
        <p className="text-muted-foreground">
          Process multiple PDF files simultaneously with bulk operations
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="conversion-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Bulk Operations
            </CardTitle>
            <CardDescription>Process hundreds of files at once</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="upload-area">
              <div className="floating">
                <Layers className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Upload Multiple PDFs</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Select multiple files for batch processing
              </p>
              <input
                type="file"
                multiple
                className="hidden"
                id="batch-files"
                accept=".pdf"
                onChange={handleFileSelect}
              />
              <Button 
                variant="outline"
                onClick={() => document.getElementById('batch-files')?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Select Multiple Files
              </Button>
            </div>

            {selectedFiles.length > 0 && (
              <div className="space-y-2">
                <span className="text-sm font-medium">Selected Files: {selectedFiles.length}</span>
                <Badge variant="secondary">{selectedFiles.length} files ready for processing</Badge>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Batch Operations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <FileText className="h-4 w-4 text-blue-500" />
                <span>Bulk conversion</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Parallel processing</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Progress tracking</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Download className="h-4 w-4 text-purple-500" />
                <span>Batch download</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Processing Speed
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>10 files:</span>
                <span className="text-muted-foreground">2-5 minutes</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>100 files:</span>
                <span className="text-muted-foreground">15-30 minutes</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}