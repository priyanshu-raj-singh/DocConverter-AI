import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  FileText, 
  Image, 
  FileSpreadsheet, 
  Presentation,
  Download,
  X,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Eye,
  Info,
  Zap,
  Clock,
  FileCheck
} from 'lucide-react';
import { toast } from 'sonner';

interface ConversionJob {
  id: string;
  fileName: string;
  fileSize: number;
  fromFormat: string;
  toFormat: string;
  status: 'uploading' | 'converting' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  estimatedTime?: number;
  actualTime?: number;
  preview?: string;
}

const conversionTypes = [
  {
    id: 'pdf-word',
    title: 'PDF to Word',
    description: 'Convert PDF documents to editable Word files with preserved formatting',
    icon: FileText,
    from: 'PDF',
    to: 'DOCX',
    color: 'bg-blue-500',
    accuracy: 95,
    avgTime: '2-5 seconds',
    supportedFeatures: ['Text', 'Images', 'Tables', 'Formatting'],
    limitations: ['Complex layouts may need adjustment']
  },
  {
    id: 'word-pdf',
    title: 'Word to PDF',
    description: 'Convert Word documents to PDF format with high fidelity',
    icon: FileText,
    from: 'DOCX',
    to: 'PDF',
    color: 'bg-red-500',
    accuracy: 99,
    avgTime: '1-3 seconds',
    supportedFeatures: ['All formatting', 'Images', 'Headers/Footers', 'Hyperlinks'],
    limitations: ['None']
  },
  {
    id: 'pdf-excel',
    title: 'PDF to Excel',
    description: 'Extract tables and data from PDF to Excel spreadsheets',
    icon: FileSpreadsheet,
    from: 'PDF',
    to: 'XLSX',
    color: 'bg-green-500',
    accuracy: 88,
    avgTime: '3-8 seconds',
    supportedFeatures: ['Tables', 'Data extraction', 'Multiple sheets'],
    limitations: ['Works best with structured tables']
  },
  {
    id: 'excel-pdf',
    title: 'Excel to PDF',
    description: 'Convert Excel spreadsheets to PDF with all formatting',
    icon: FileSpreadsheet,
    from: 'XLSX',
    to: 'PDF',
    color: 'bg-green-500',
    accuracy: 97,
    avgTime: '2-4 seconds',
    supportedFeatures: ['Charts', 'Formulas', 'Multiple sheets', 'Formatting'],
    limitations: ['Very large files may take longer']
  },
  {
    id: 'pdf-ppt',
    title: 'PDF to PowerPoint',
    description: 'Convert PDF pages to editable PowerPoint slides',
    icon: Presentation,
    from: 'PDF',
    to: 'PPTX',
    color: 'bg-orange-500',
    accuracy: 85,
    avgTime: '4-10 seconds',
    supportedFeatures: ['Images', 'Text boxes', 'Basic layouts'],
    limitations: ['Complex layouts may need manual adjustment']
  },
  {
    id: 'ppt-pdf',
    title: 'PowerPoint to PDF',
    description: 'Convert presentations to PDF format with animations preserved as static',
    icon: Presentation,
    from: 'PPTX',
    to: 'PDF',
    color: 'bg-orange-500',
    accuracy: 98,
    avgTime: '2-6 seconds',
    supportedFeatures: ['All slides', 'Images', 'Text', 'Shapes'],
    limitations: ['Animations become static']
  },
  {
    id: 'image-pdf',
    title: 'Image to PDF',
    description: 'Convert JPG, PNG images to PDF documents with OCR capability',
    icon: Image,
    from: 'JPG/PNG',
    to: 'PDF',
    color: 'bg-purple-500',
    accuracy: 100,
    avgTime: '1-2 seconds',
    supportedFeatures: ['Multiple images', 'OCR text layer', 'Compression'],
    limitations: ['None']
  },
  {
    id: 'pdf-image',
    title: 'PDF to Image',
    description: 'Convert PDF pages to high-quality JPG or PNG images',
    icon: Image,
    from: 'PDF',
    to: 'JPG/PNG',
    color: 'bg-purple-500',
    accuracy: 100,
    avgTime: '1-3 seconds',
    supportedFeatures: ['High resolution', 'Multiple pages', 'Custom DPI'],
    limitations: ['Large PDFs create many images']
  }
];

const formatSupport = {
  'PDF': ['.pdf'],
  'DOCX': ['.docx', '.doc'],
  'XLSX': ['.xlsx', '.xls'],
  'PPTX': ['.pptx', '.ppt'],
  'JPG/PNG': ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']
};

export default function Converter() {
  const [jobs, setJobs] = useState<ConversionJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File, expectedFormat: string): { valid: boolean; error?: string } => {
    const supportedExtensions = formatSupport[expectedFormat as keyof typeof formatSupport] || [];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!supportedExtensions.includes(fileExtension)) {
      return {
        valid: false,
        error: `Invalid file type. Expected: ${supportedExtensions.join(', ')}`
      };
    }

    // File size validation (100MB limit)
    if (file.size > 100 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 100MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, conversionType: string): number => {
    // Base time in seconds based on conversion complexity
    const baseTime = {
      'pdf-word': 3,
      'word-pdf': 2,
      'pdf-excel': 5,
      'excel-pdf': 3,
      'pdf-ppt': 6,
      'ppt-pdf': 4,
      'image-pdf': 1,
      'pdf-image': 2
    }[conversionType] || 3;

    // Add time based on file size (1 second per 5MB)
    const sizeTime = Math.ceil(fileSize / (5 * 1024 * 1024));
    
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, conversionType: any) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, conversionType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, conversionType: any) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, conversionType);
  };

  const handleFiles = (files: File[], conversionType: any) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file, conversionType.from);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    // Update selected files for preview only
    setSelectedFiles(prev => ({
      ...prev,
      [conversionType.id]: validFiles
    }));

    toast.success(`${validFiles.length} file(s) ready for conversion`);
  };

  const startConversion = (conversionType: any) => {
    const files = selectedFiles[conversionType.id] || [];
    if (files.length === 0) {
      toast.error('Please select files first');
      return;
    }

    files.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, conversionType.id);
      
      const newJob: ConversionJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        fromFormat: conversionType.from,
        toFormat: conversionType.to,
        status: 'uploading',
        progress: 0,
        estimatedTime
      };

      setJobs(prev => [...prev, newJob]);
      simulateConversion(jobId, estimatedTime);
    });

    toast.success(`Started converting ${files.length} file(s)`);
  };

  const simulateConversion = (jobId: string, estimatedTime: number) => {
    const startTime = Date.now();
    
    // Simulate upload progress (20% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 200; // 20% of estimated time in ms
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 15 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'converting', progress: 0 }
            : job
        ));

        // Simulate conversion (80% of total time)
        const conversionDuration = estimatedTime * 800;
        setTimeout(() => {
          const conversionInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 8 + 2;
                if (newProgress >= 100) {
                  clearInterval(conversionInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Create converted file for download
                  try {
                    const downloadBlob = downloadUtils.createConvertedFile(job.fileName, job.fromFormat, job.toFormat);
                    const downloadUrl = URL.createObjectURL(downloadBlob);
                    
                    return {
                      ...job,
                      status: 'completed',
                      progress: 100,
                      downloadUrl,
                      actualTime,
                      preview: `Conversion completed in ${actualTime}s. File size: ${formatFileSize(job.fileSize * 0.95)}`
                    };
                  } catch (error) {
                    console.error('Error creating download file:', error);
                    return {
                      ...job,
                      status: 'error',
                      progress: 100,
                      error: 'Failed to create download file. Please try again.',
                      actualTime
                    };
                  }
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, conversionDuration / 50);
        }, 500);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateConversion(jobId, job.estimatedTime || 3);
    }
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const getStatusIcon = (status: ConversionJob['status']) => {
    switch (status) {
      case 'uploading':
      case 'converting':
        return <RefreshCw className="h-4 w-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: ConversionJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'converting':
        return 'Converting...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2">Document Converter</h1>
          <p className="text-muted-foreground">
            Convert your documents between different formats with high accuracy and speed
          </p>
        </div>

        <Tabs defaultValue="popular" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="pdf">PDF Tools</TabsTrigger>
            <TabsTrigger value="office">Office</TabsTrigger>
            <TabsTrigger value="image">Images</TabsTrigger>
          </TabsList>

          <TabsContent value="popular" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {conversionTypes.slice(0, 6).map((type) => {
                const Icon = type.icon;
                const files = selectedFiles[type.id] || [];
                return (
                  <Card key={type.id} className="conversion-card group">
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-3">
                        <div className={`card-icon h-10 w-10 rounded-lg ${type.color} flex items-center justify-center transition-all duration-300`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{type.title}</CardTitle>
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="h-4 w-4 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2">
                                  <p><strong>Accuracy:</strong> {type.accuracy}%</p>
                                  <p><strong>Avg Time:</strong> {type.avgTime}</p>
                                  <p><strong>Features:</strong> {type.supportedFeatures.join(', ')}</p>
                                  {type.limitations[0] !== 'None' && (
                                    <p><strong>Note:</strong> {type.limitations.join(', ')}</p>
                                  )}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                          <CardDescription className="text-sm">
                            {type.description}
                          </CardDescription>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {type.accuracy}% accuracy
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <Clock className="h-3 w-3 mr-1" />
                              {type.avgTime}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {/* File Preview */}
                      {files.length > 0 && (
                        <div className="mb-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(type.id)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {files.slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {files.length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{files.length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      <div
                        className={`upload-area ${dragOver === type.id ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, type.id)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, type)}
                      >
                        <div className="floating">
                          <Upload className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Drag & drop {type.from} files here
                        </p>
                        <p className="text-xs text-muted-foreground mb-4">
                          Supported: {formatSupport[type.from as keyof typeof formatSupport]?.join(', ')}
                        </p>
                        <input
                          ref={el => fileInputRefs.current[type.id] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${type.id}`}
                          onChange={(e) => handleFileSelect(e, type)}
                          accept={formatSupport[type.from as keyof typeof formatSupport]?.join(',')}
                        />
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => document.getElementById(`file-${type.id}`)?.click()}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Zap className="h-4 w-4 mr-2" />
                          Select Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="pdf">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {conversionTypes.filter(type => type.from === 'PDF' || type.to === 'PDF').map((type) => {
                const Icon = type.icon;
                const files = selectedFiles[type.id] || [];
                return (
                  <Card key={type.id} className="conversion-card group">
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-3">
                        <div className={`card-icon h-10 w-10 rounded-lg ${type.color} flex items-center justify-center transition-all duration-300`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{type.title}</CardTitle>
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="h-4 w-4 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2">
                                  <p><strong>Accuracy:</strong> {type.accuracy}%</p>
                                  <p><strong>Avg Time:</strong> {type.avgTime}</p>
                                  <p><strong>Features:</strong> {type.supportedFeatures.join(', ')}</p>
                                  {type.limitations[0] !== 'None' && (
                                    <p><strong>Note:</strong> {type.limitations.join(', ')}</p>
                                  )}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                          <CardDescription className="text-sm">
                            {type.description}
                          </CardDescription>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {type.accuracy}% accuracy
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <Clock className="h-3 w-3 mr-1" />
                              {type.avgTime}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {files.length > 0 && (
                        <div className="mb-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(type.id)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {files.slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {files.length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{files.length - 3} more files
                            </div>
                          )}
                          <div className="mt-3 pt-3 border-t">
                            <Button 
                              onClick={() => startConversion(type)}
                              className="w-full"
                              size="sm"
                            >
                              <Zap className="h-4 w-4 mr-2" />
                              Convert {files.length} File{files.length !== 1 ? 's' : ''}
                            </Button>
                          </div>
                        </div>
                      )}

                      <div
                        className={`upload-area ${dragOver === type.id ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, type.id)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, type)}
                      >
                        <div className="floating">
                          <Upload className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Drag & drop {type.from} files here
                        </p>
                        <p className="text-xs text-muted-foreground mb-4">
                          Supported: {formatSupport[type.from as keyof typeof formatSupport]?.join(', ')}
                        </p>
                        <input
                          ref={el => fileInputRefs.current[type.id] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${type.id}`}
                          onChange={(e) => handleFileSelect(e, type)}
                          accept={formatSupport[type.from as keyof typeof formatSupport]?.join(',')}
                        />
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            const input = document.getElementById(`file-${type.id}`) as HTMLInputElement;
                            if (input) {
                              input.click();
                            } else {
                              console.error('File input not found:', `file-${type.id}`);
                              toast.error('File input not available. Please refresh the page.');
                            }
                          }}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Zap className="h-4 w-4 mr-2" />
                          Select Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="office">
            <div className="text-center py-8">
              <p className="text-muted-foreground">Office format conversions available in PDF Tools tab</p>
            </div>
          </TabsContent>

          <TabsContent value="image">
            <div className="grid md:grid-cols-2 gap-6">
              {conversionTypes.filter(type => type.icon === Image).map((type) => {
                const Icon = type.icon;
                const files = selectedFiles[type.id] || [];
                return (
                  <Card key={type.id} className="conversion-card group">
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-3">
                        <div className={`card-icon h-10 w-10 rounded-lg ${type.color} flex items-center justify-center transition-all duration-300`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{type.title}</CardTitle>
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="h-4 w-4 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2">
                                  <p><strong>Accuracy:</strong> {type.accuracy}%</p>
                                  <p><strong>Avg Time:</strong> {type.avgTime}</p>
                                  <p><strong>Features:</strong> {type.supportedFeatures.join(', ')}</p>
                                  {type.limitations[0] !== 'None' && (
                                    <p><strong>Note:</strong> {type.limitations.join(', ')}</p>
                                  )}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                          <CardDescription className="text-sm">
                            {type.description}
                          </CardDescription>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {type.accuracy}% accuracy
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <Clock className="h-3 w-3 mr-1" />
                              {type.avgTime}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {files.length > 0 && (
                        <div className="mb-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(type.id)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {files.slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {files.length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{files.length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      <div
                        className={`upload-area ${dragOver === type.id ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, type.id)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, type)}
                      >
                        <div className="floating">
                          <Upload className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Drag & drop {type.from} files here
                        </p>
                        <p className="text-xs text-muted-foreground mb-4">
                          Supported: {formatSupport[type.from as keyof typeof formatSupport]?.join(', ')}
                        </p>
                        <input
                          ref={el => fileInputRefs.current[type.id] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${type.id}`}
                          onChange={(e) => handleFileSelect(e, type)}
                          accept={formatSupport[type.from as keyof typeof formatSupport]?.join(',')}
                        />
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => document.getElementById(`file-${type.id}`)?.click()}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Zap className="h-4 w-4 mr-2" />
                          Select Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>

        {/* Enhanced Conversion Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="h-5 w-5" />
                Conversion Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your file conversions with real-time updates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {job.fromFormat} → {job.toFormat}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && job.downloadUrl !== 'generating' && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const extension = downloadUtils.getOutputExtension(job.fromFormat, job.toFormat);
                            const link = document.createElement('a');
                            link.href = job.downloadUrl;
                            link.download = `converted-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${extension}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Download started!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'completed' && job.downloadUrl === 'generating' && (
                        <Button size="sm" disabled>
                          <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                          Preparing...
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'converting') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>{job.status === 'uploading' ? 'Uploading...' : 'Converting...'}</span>
                      </div>
                    </div>
                  )}
                  
                  {job.preview && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <p className="text-sm text-green-800 dark:text-green-200">{job.preview}</p>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}