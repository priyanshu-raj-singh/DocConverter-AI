import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  GitCompare, 
  Download,
  FileText,
  Plus,
  Minus,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Target,
  Clock,
  Eye,
  ArrowLeftRight
} from 'lucide-react';
import { toast } from 'sonner';

interface CompareJob {
  id: string;
  file1Name: string;
  file2Name: string;
  file1Size: number;
  file2Size: number;
  compareType: string;
  status: 'uploading' | 'analyzing' | 'comparing' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  differences?: number;
  similarity?: number;
}

const compareTypes = {
  text: {
    title: 'Text Comparison',
    icon: FileText,
    color: 'bg-blue-500',
    description: 'Compare text content and identify changes',
    features: ['Word-by-word comparison', 'Paragraph analysis', 'Change highlighting']
  },
  visual: {
    title: 'Visual Comparison',
    icon: Eye,
    color: 'bg-green-500',
    description: 'Compare visual layout and formatting differences',
    features: ['Layout changes', 'Image differences', 'Formatting variations']
  },
  structure: {
    title: 'Structure Comparison',
    icon: ArrowLeftRight,
    color: 'bg-purple-500',
    description: 'Analyze document structure and organization',
    features: ['Section changes', 'Heading modifications', 'Content reorganization']
  },
  comprehensive: {
    title: 'Comprehensive Analysis',
    icon: GitCompare,
    color: 'bg-orange-500',
    description: 'Complete comparison including text, visual, and structure',
    features: ['All comparison types', 'Detailed report', 'Change summary']
  }
};

export default function PDFCompare() {
  const [jobs, setJobs] = useState<CompareJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [compareSettings, setCompareSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for comparison'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (file1Size: number, file2Size: number, compareType: string): number => {
    const baseTime = {
      'text': 10,
      'visual': 15,
      'structure': 12,
      'comprehensive': 20
    }[compareType] || 12;

    const totalSize = file1Size + file2Size;
    const sizeTime = Math.ceil(totalSize / (4 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, compareType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, compareType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, compareType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, compareType);
  };

  const handleFiles = (files: File[], compareType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length < 2) {
      toast.error('Please select at least 2 PDF files to compare');
      return;
    }

    setSelectedFiles(prev => ({
      ...prev,
      [compareType]: validFiles
    }));

    // Process files in pairs
    for (let i = 0; i < validFiles.length - 1; i++) {
      const file1 = validFiles[i];
      const file2 = validFiles[i + 1];
      
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file1.size, file2.size, compareType);
      
      const newJob: CompareJob = {
        id: jobId,
        file1Name: file1.name,
        file2Name: file2.name,
        file1Size: file1.size,
        file2Size: file2.size,
        compareType,
        status: 'uploading',
        progress: 0,
        estimatedTime
      };

      setJobs(prev => [...prev, newJob]);
      simulateComparison(jobId, estimatedTime, compareType);
    }

    toast.success(`Started comparison for ${Math.floor(validFiles.length / 2)} file pair(s)`);
  };

  const simulateComparison = (jobId: string, estimatedTime: number, compareType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (25% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 250;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 8 + 4;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'analyzing', progress: 0 }
            : job
        ));

        // Simulate analysis (35% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'comparing', progress: 0 }
              : job
          ));

          // Simulate comparison (40% of total time)
          const comparingDuration = estimatedTime * 400;
          const comparingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 3 + 1;
                if (newProgress >= 100) {
                  clearInterval(comparingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate comparison result
                  const differences = Math.floor(Math.random() * 50) + 5;
                  const similarity = Math.floor(Math.random() * 30) + 70; // 70-99%
                  const result = generateComparisonResult(compareType, differences, similarity);
                  const downloadBlob = createComparisonReport(compareType, job.file1Name, job.file2Name, differences, similarity);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result: getComparisonSummary(compareType, differences, similarity),
                    differences,
                    similarity
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, comparingDuration / 50);
        }, estimatedTime * 350);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 25);
  };

  const generateComparisonResult = (compareType: string, differences: number, similarity: number): string => {
    switch (compareType) {
      case 'text':
        return generateTextComparison(differences, similarity);
      case 'visual':
        return generateVisualComparison(differences, similarity);
      case 'structure':
        return generateStructureComparison(differences, similarity);
      case 'comprehensive':
        return generateComprehensiveComparison(differences, similarity);
      default:
        return 'Comparison completed successfully';
    }
  };

  const generateTextComparison = (differences: number, similarity: number): string => {
    let report = `# Text Comparison Report\n\n`;
    report += `**Similarity Score:** ${similarity}%\n`;
    report += `**Differences Found:** ${differences}\n\n`;
    report += `## Text Changes Summary\n\n`;
    report += `### Added Content\n`;
    report += `- ${Math.floor(differences * 0.4)} new paragraphs detected\n`;
    report += `- ${Math.floor(differences * 0.3)} new sentences added\n\n`;
    report += `### Removed Content\n`;
    report += `- ${Math.floor(differences * 0.2)} paragraphs removed\n`;
    report += `- ${Math.floor(differences * 0.1)} sentences deleted\n\n`;
    report += `### Modified Content\n`;
    report += `- ${Math.floor(differences * 0.5)} text modifications\n`;
    report += `- ${Math.floor(differences * 0.3)} word changes\n\n`;
    report += `## Detailed Analysis\n\n`;
    report += `The documents show ${similarity > 85 ? 'high' : similarity > 70 ? 'moderate' : 'low'} similarity in text content. `;
    report += `Key changes include content additions, deletions, and modifications throughout the document.`;
    
    return report;
  };

  const generateVisualComparison = (differences: number, similarity: number): string => {
    let report = `# Visual Comparison Report\n\n`;
    report += `**Visual Similarity:** ${similarity}%\n`;
    report += `**Layout Differences:** ${differences}\n\n`;
    report += `## Visual Changes Summary\n\n`;
    report += `### Layout Changes\n`;
    report += `- ${Math.floor(differences * 0.3)} formatting modifications\n`;
    report += `- ${Math.floor(differences * 0.2)} margin adjustments\n\n`;
    report += `### Image Differences\n`;
    report += `- ${Math.floor(differences * 0.1)} images added/removed\n`;
    report += `- ${Math.floor(differences * 0.1)} image modifications\n\n`;
    report += `### Font and Style Changes\n`;
    report += `- ${Math.floor(differences * 0.4)} font style changes\n`;
    report += `- ${Math.floor(differences * 0.2)} color modifications\n\n`;
    report += `## Visual Analysis\n\n`;
    report += `The documents maintain ${similarity > 80 ? 'consistent' : 'varied'} visual presentation. `;
    report += `Notable changes in layout, formatting, and visual elements have been identified.`;
    
    return report;
  };

  const generateStructureComparison = (differences: number, similarity: number): string => {
    let report = `# Structure Comparison Report\n\n`;
    report += `**Structural Similarity:** ${similarity}%\n`;
    report += `**Structure Changes:** ${differences}\n\n`;
    report += `## Structure Analysis\n\n`;
    report += `### Section Changes\n`;
    report += `- ${Math.floor(differences * 0.3)} sections added/removed\n`;
    report += `- ${Math.floor(differences * 0.2)} section reordering\n\n`;
    report += `### Heading Modifications\n`;
    report += `- ${Math.floor(differences * 0.4)} heading changes\n`;
    report += `- ${Math.floor(differences * 0.2)} heading level adjustments\n\n`;
    report += `### Content Organization\n`;
    report += `- ${Math.floor(differences * 0.3)} content reorganization\n`;
    report += `- ${Math.floor(differences * 0.1)} structural improvements\n\n`;
    report += `## Structural Assessment\n\n`;
    report += `The document structure shows ${similarity > 85 ? 'minimal' : similarity > 70 ? 'moderate' : 'significant'} changes. `;
    report += `Changes primarily involve section organization and content hierarchy.`;
    
    return report;
  };

  const generateComprehensiveComparison = (differences: number, similarity: number): string => {
    let report = `# Comprehensive Comparison Report\n\n`;
    report += `**Overall Similarity:** ${similarity}%\n`;
    report += `**Total Differences:** ${differences}\n\n`;
    report += `## Executive Summary\n\n`;
    report += `This comprehensive analysis covers text content, visual presentation, and document structure. `;
    report += `The documents show ${similarity}% overall similarity with ${differences} identified differences.\n\n`;
    report += `## Text Analysis (40% weight)\n`;
    report += `- Content changes: ${Math.floor(differences * 0.4)}\n`;
    report += `- Text similarity: ${similarity + Math.floor(Math.random() * 10 - 5)}%\n\n`;
    report += `## Visual Analysis (30% weight)\n`;
    report += `- Layout changes: ${Math.floor(differences * 0.3)}\n`;
    report += `- Visual similarity: ${similarity + Math.floor(Math.random() * 10 - 5)}%\n\n`;
    report += `## Structure Analysis (30% weight)\n`;
    report += `- Structural changes: ${Math.floor(differences * 0.3)}\n`;
    report += `- Structure similarity: ${similarity + Math.floor(Math.random() * 10 - 5)}%\n\n`;
    report += `## Recommendations\n\n`;
    report += `Based on the analysis, the documents are ${similarity > 85 ? 'highly similar' : similarity > 70 ? 'moderately similar' : 'significantly different'}. `;
    report += `Review the detailed change log for specific modifications and their impact.`;
    
    return report;
  };

  const createComparisonReport = (compareType: string, file1Name: string, file2Name: string, differences: number, similarity: number): Blob => {
    const result = generateComparisonResult(compareType, differences, similarity);
    
    let content = `# PDF Comparison Report\n\n`;
    content += `**Comparison Type:** ${compareTypes[compareType as keyof typeof compareTypes]?.title}\n`;
    content += `**File 1:** ${file1Name}\n`;
    content += `**File 2:** ${file2Name}\n`;
    content += `**Generated:** ${new Date().toLocaleString()}\n\n`;
    content += `---\n\n`;
    content += result;
    content += `\n\n---\n\n`;
    content += `## Change Log\n\n`;
    
    // Generate sample change entries
    for (let i = 1; i <= Math.min(differences, 10); i++) {
      content += `### Change ${i}\n`;
      content += `**Type:** ${['Addition', 'Deletion', 'Modification'][Math.floor(Math.random() * 3)]}\n`;
      content += `**Location:** Page ${Math.floor(Math.random() * 5) + 1}\n`;
      content += `**Description:** Sample change description for difference ${i}\n\n`;
    }
    
    return downloadUtils.createPDF(`comparison-report-${Date.now()}`, content);
  };

  const getComparisonSummary = (compareType: string, differences: number, similarity: number): string => {
    const typeName = compareTypes[compareType as keyof typeof compareTypes]?.title;
    return `${typeName} completed. Found ${differences} differences with ${similarity}% similarity. Detailed report generated.`;
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateComparison(jobId, job.estimatedTime || 12, job.compareType);
    }
  };

  const getStatusIcon = (status: CompareJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'analyzing':
        return <Eye className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'comparing':
        return <GitCompare className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: CompareJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'analyzing':
        return 'Analyzing Documents...';
      case 'comparing':
        return 'Comparing Content...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <GitCompare className="h-8 w-8 text-primary floating" />
            PDF Compare
          </h1>
          <p className="text-muted-foreground">
            Compare PDF documents and identify differences with AI-powered analysis
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {Object.entries(compareTypes).map(([key, type]) => (
            <Card key={key} className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <type.icon className="h-5 w-5" />
                  {type.title}
                </CardTitle>
                <CardDescription>{type.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Features */}
                <div>
                  <h4 className="font-medium mb-2">Features:</h4>
                  <div className="space-y-1">
                    {type.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* File Preview */}
                {selectedFiles[key]?.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Selected Files:</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => clearFiles(key)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                    {selectedFiles[key].slice(0, 4).map((file, index) => (
                      <div key={index} className="file-preview">
                        <div className="flex items-center gap-2">
                          <FileCheck className="h-4 w-4 text-green-500" />
                          <span className="text-sm truncate flex-1">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatFileSize(file.size)}
                          </span>
                        </div>
                      </div>
                    ))}
                    {selectedFiles[key].length > 4 && (
                      <div className="text-xs text-muted-foreground text-center">
                        +{selectedFiles[key].length - 4} more files
                      </div>
                    )}
                  </div>
                )}

                {/* Upload Area */}
                <div
                  className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                  onDragOver={(e) => handleDragOver(e, key)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, key)}
                >
                  <div className="floating">
                    <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold mb-2">Upload PDFs to Compare</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Select 2 or more PDF files for {type.title.toLowerCase()}
                  </p>
                  <input
                    ref={el => fileInputRefs.current[key] = el}
                    type="file"
                    multiple
                    className="hidden"
                    id={`file-${key}`}
                    accept=".pdf"
                    onChange={(e) => handleFileSelect(e, key)}
                  />
                  <Button 
                    variant="outline"
                    onClick={() => document.getElementById(`file-${key}`)?.click()}
                    className="transition-all duration-200 hover:scale-105"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select PDF Files
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Comparison Jobs */}
        {jobs.length > 0 && (
          <Card className="bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitCompare className="h-5 w-5" />
                Comparison Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your PDF comparison tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <GitCompare className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{job.file1Name} vs {job.file2Name}</span>
                          <Badge variant="outline" className="text-xs">
                            {compareTypes[job.compareType as keyof typeof compareTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Files: {formatFileSize(job.file1Size)} + {formatFileSize(job.file2Size)}</span>
                          {job.differences && (
                            <span className="text-orange-600">{job.differences} differences</span>
                          )}
                          {job.similarity && (
                            <span className="text-green-600">{job.similarity}% similar</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            link.download = `comparison-report-${job.file1Name.replace(/\.[^/.]+$/, '')}-vs-${job.file2Name.replace(/\.[^/.]+$/, '')}-${Date.now()}.pdf`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Comparison report downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'analyzing' || job.status === 'comparing') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading files...'}
                          {job.status === 'analyzing' && 'Analyzing documents...'}
                          {job.status === 'comparing' && 'Comparing content...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Comparison Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Features Info */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Comparison Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Plus className="h-4 w-4 text-green-500" />
                <span>Addition detection</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Minus className="h-4 w-4 text-red-500" />
                <span>Deletion identification</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <ArrowLeftRight className="h-4 w-4 text-blue-500" />
                <span>Modification tracking</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Similarity scoring</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Processing Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Text comparison:</span>
                <span className="text-muted-foreground">8-15 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Visual comparison:</span>
                <span className="text-muted-foreground">12-20 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Structure comparison:</span>
                <span className="text-muted-foreground">10-18 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Comprehensive:</span>
                <span className="text-muted-foreground">15-25 seconds</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Output Formats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm">• Detailed PDF report</div>
              <div className="text-sm">• Change summary</div>
              <div className="text-sm">• Similarity metrics</div>
              <div className="text-sm">• Visual diff highlights</div>
              <div className="text-sm">• Structured change log</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TooltipProvider>
  );
}