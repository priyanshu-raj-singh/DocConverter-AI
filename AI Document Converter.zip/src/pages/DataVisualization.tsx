import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  BarChart3, 
  Download,
  FileText,
  PieChart,
  LineChart,
  TrendingUp,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Target,
  Clock,
  Database,
  Table,
  Image
} from 'lucide-react';
import { toast } from 'sonner';

interface VisualizationJob {
  id: string;
  fileName: string;
  fileSize: number;
  chartType: string;
  status: 'uploading' | 'extracting' | 'generating' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  settings?: any;
  dataPoints?: number;
}

const chartTypes = {
  auto: {
    title: 'Auto-Detect Charts',
    icon: BarChart3,
    color: 'bg-blue-500',
    description: 'Automatically detect and create appropriate charts from your data',
    formats: ['Bar Chart', 'Line Chart', 'Pie Chart', 'Scatter Plot']
  },
  bar: {
    title: 'Bar Charts',
    icon: BarChart3,
    color: 'bg-green-500',
    description: 'Create bar charts for categorical data comparison',
    formats: ['Vertical Bars', 'Horizontal Bars', 'Grouped Bars', 'Stacked Bars']
  },
  line: {
    title: 'Line Charts',
    icon: LineChart,
    color: 'bg-purple-500',
    description: 'Generate line charts for trends and time series data',
    formats: ['Simple Line', 'Multi-Line', 'Area Chart', 'Stepped Line']
  },
  pie: {
    title: 'Pie Charts',
    icon: PieChart,
    color: 'bg-orange-500',
    description: 'Create pie charts for proportional data visualization',
    formats: ['Standard Pie', 'Donut Chart', 'Exploded Pie', '3D Pie']
  },
  advanced: {
    title: 'Advanced Charts',
    icon: TrendingUp,
    color: 'bg-red-500',
    description: 'Generate complex visualizations and dashboards',
    formats: ['Heatmap', 'Bubble Chart', 'Radar Chart', 'Treemap']
  }
};

const outputFormats = [
  { id: 'png', name: 'PNG Image', description: 'High-quality raster image' },
  { id: 'svg', name: 'SVG Vector', description: 'Scalable vector graphics' },
  { id: 'pdf', name: 'PDF Document', description: 'Printable PDF format' },
  { id: 'html', name: 'Interactive HTML', description: 'Interactive web chart' },
  { id: 'excel', name: 'Excel with Charts', description: 'Excel file with embedded charts' }
];

const colorSchemes = [
  { id: 'default', name: 'Default', colors: ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'] },
  { id: 'professional', name: 'Professional', colors: ['#1f2937', '#374151', '#6b7280', '#9ca3af', '#d1d5db'] },
  { id: 'vibrant', name: 'Vibrant', colors: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7'] },
  { id: 'pastel', name: 'Pastel', colors: ['#a8e6cf', '#dcedc1', '#ffd3a5', '#ffaaa5', '#ff8b94'] },
  { id: 'corporate', name: 'Corporate', colors: ['#2c3e50', '#3498db', '#e74c3c', '#f39c12', '#9b59b6'] }
];

export default function DataVisualization() {
  const [jobs, setJobs] = useState<VisualizationJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [vizSettings, setVizSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for data visualization'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, chartType: string): number => {
    const baseTime = {
      'auto': 12,
      'bar': 8,
      'line': 8,
      'pie': 6,
      'advanced': 15
    }[chartType] || 10;

    const sizeTime = Math.ceil(fileSize / (3 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, chartType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, chartType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, chartType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, chartType);
  };

  const handleFiles = (files: File[], chartType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(prev => ({
      ...prev,
      [chartType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, chartType);
      
      const newJob: VisualizationJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        chartType,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        settings: vizSettings[chartType] || {}
      };

      setJobs(prev => [...prev, newJob]);
      simulateVisualization(jobId, estimatedTime, chartType);
    });

    toast.success(`Started ${chartTypes[chartType as keyof typeof chartTypes].title} generation for ${validFiles.length} file(s)`);
  };

  const simulateVisualization = (jobId: string, estimatedTime: number, chartType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (15% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 150;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 12 + 3;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'extracting', progress: 0 }
            : job
        ));

        // Simulate data extraction (35% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'generating', progress: 0 }
              : job
          ));

          // Simulate chart generation (50% of total time)
          const generationDuration = estimatedTime * 500;
          const generationInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 5 + 1;
                if (newProgress >= 100) {
                  clearInterval(generationInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate result
                  const dataPoints = Math.floor(Math.random() * 50) + 20;
                  const result = generateVisualizationResult(chartType, job.settings, dataPoints);
                  const downloadBlob = createVisualizationFile(chartType, job.fileName, job.settings);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result,
                    dataPoints
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, generationDuration / 50);
        }, estimatedTime * 350);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateVisualizationResult = (chartType: string, settings: any, dataPoints: number): string => {
    const chartName = chartTypes[chartType as keyof typeof chartTypes]?.title;
    const format = settings?.format || chartTypes[chartType as keyof typeof chartTypes]?.formats[0];
    const outputFormat = settings?.outputFormat || 'png';
    
    return `Successfully generated ${chartName} with ${dataPoints} data points. Chart format: ${format}. Output: ${outputFormat.toUpperCase()}. Ready for download and analysis.`;
  };

  const createVisualizationFile = (chartType: string, fileName: string, settings: any): Blob => {
    const outputFormat = settings?.outputFormat || 'png';
    
    switch (outputFormat) {
      case 'png':
      case 'svg':
        // Create a simple chart image (in real implementation, this would be actual chart generation)
        const canvas = document.createElement('canvas');
        canvas.width = 800;
        canvas.height = 600;
        const ctx = canvas.getContext('2d');
        
        if (ctx) {
          // Background
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, 800, 600);
          
          // Title
          ctx.fillStyle = '#333333';
          ctx.font = '24px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(`${chartTypes[chartType as keyof typeof chartTypes]?.title} - ${fileName}`, 400, 50);
          
          // Sample chart elements
          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(100, 100, 50, 200);
          ctx.fillRect(200, 150, 50, 150);
          ctx.fillRect(300, 80, 50, 220);
          ctx.fillRect(400, 120, 50, 180);
          ctx.fillRect(500, 90, 50, 210);
          
          // Labels
          ctx.font = '14px Arial';
          ctx.fillStyle = '#666666';
          ctx.fillText('Sample Chart Generated from PDF Data', 400, 350);
          ctx.fillText('Data extracted and visualized automatically', 400, 380);
        }
        
        return new Promise<Blob>((resolve) => {
          canvas.toBlob((blob) => {
            resolve(blob || new Blob());
          }, outputFormat === 'png' ? 'image/png' : 'image/svg+xml');
        }) as any;
        
      case 'pdf':
        return downloadUtils.createPDF(fileName, `Data Visualization Report\n\nChart Type: ${chartTypes[chartType as keyof typeof chartTypes]?.title}\nGenerated from: ${fileName}\nCreated: ${new Date().toLocaleString()}`);
        
      case 'html':
        const htmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>Data Visualization - ${fileName}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .chart-container { width: 800px; height: 400px; margin: 20px auto; }
    </style>
</head>
<body>
    <h1>Data Visualization from ${fileName}</h1>
    <div class="chart-container">
        <canvas id="myChart"></canvas>
    </div>
    <script>
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: '${chartType === 'bar' ? 'bar' : chartType === 'line' ? 'line' : 'pie'}',
            data: {
                labels: ['Data 1', 'Data 2', 'Data 3', 'Data 4', 'Data 5'],
                datasets: [{
                    label: 'Extracted Data',
                    data: [12, 19, 3, 5, 2],
                    backgroundColor: ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Generated from PDF Data'
                    }
                }
            }
        });
    </script>
</body>
</html>`;
        return new Blob([htmlContent], { type: 'text/html' });
        
      case 'excel':
        return downloadUtils.createExcel(fileName);
        
      default:
        return new Blob(['Chart data generated successfully'], { type: 'text/plain' });
    }
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateVisualization(jobId, job.estimatedTime || 10, job.chartType);
    }
  };

  const getStatusIcon = (status: VisualizationJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'extracting':
        return <Database className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'generating':
        return <BarChart3 className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: VisualizationJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'extracting':
        return 'Extracting Data...';
      case 'generating':
        return 'Generating Charts...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const getFileExtension = (outputFormat: string): string => {
    switch (outputFormat) {
      case 'png': return 'png';
      case 'svg': return 'svg';
      case 'pdf': return 'pdf';
      case 'html': return 'html';
      case 'excel': return 'xlsx';
      default: return 'png';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <BarChart3 className="h-8 w-8 text-primary floating" />
            Data Visualization
          </h1>
          <p className="text-muted-foreground">
            Extract data from PDFs and generate beautiful charts and graphs automatically
          </p>
        </div>

        <Tabs defaultValue="auto" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="auto" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Auto
            </TabsTrigger>
            <TabsTrigger value="bar" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Bar
            </TabsTrigger>
            <TabsTrigger value="line" className="flex items-center gap-2">
              <LineChart className="h-4 w-4" />
              Line
            </TabsTrigger>
            <TabsTrigger value="pie" className="flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              Pie
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Advanced
            </TabsTrigger>
          </TabsList>

          {Object.entries(chartTypes).map(([key, type]) => (
            <TabsContent key={key} value={key} className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card className="conversion-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <type.icon className="h-5 w-5" />
                        {type.title}
                      </CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Chart Format Selection */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Chart Format:</h4>
                        <div className="grid grid-cols-2 gap-3">
                          {type.formats.map((format) => (
                            <Button
                              key={format}
                              variant={vizSettings[key]?.format === format ? "default" : "outline"}
                              className="justify-start h-auto p-3"
                              onClick={() => setVizSettings(prev => ({
                                ...prev,
                                [key]: { ...prev[key], format }
                              }))}
                            >
                              <span className="text-sm">{format}</span>
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* Output Format */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Output Format:</h4>
                        <Select
                          value={vizSettings[key]?.outputFormat || 'png'}
                          onValueChange={(value) => setVizSettings(prev => ({
                            ...prev,
                            [key]: { ...prev[key], outputFormat: value }
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select output format" />
                          </SelectTrigger>
                          <SelectContent>
                            {outputFormats.map((format) => (
                              <SelectItem key={format.id} value={format.id}>
                                <div>
                                  <div className="font-medium">{format.name}</div>
                                  <div className="text-xs text-muted-foreground">{format.description}</div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Color Scheme */}
                      <div className="space-y-4">
                        <h4 className="font-medium">Color Scheme:</h4>
                        <div className="grid grid-cols-1 gap-2">
                          {colorSchemes.map((scheme) => (
                            <Button
                              key={scheme.id}
                              variant={vizSettings[key]?.colorScheme === scheme.id ? "default" : "outline"}
                              className="justify-start h-auto p-3"
                              onClick={() => setVizSettings(prev => ({
                                ...prev,
                                [key]: { ...prev[key], colorScheme: scheme.id }
                              }))}
                            >
                              <div className="flex items-center gap-3">
                                <div className="flex gap-1">
                                  {scheme.colors.map((color, index) => (
                                    <div
                                      key={index}
                                      className="w-4 h-4 rounded-full"
                                      style={{ backgroundColor: color }}
                                    />
                                  ))}
                                </div>
                                <span className="text-sm">{scheme.name}</span>
                              </div>
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* File Preview */}
                      {selectedFiles[key]?.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Selected Files:</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => clearFiles(key)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          {selectedFiles[key].slice(0, 3).map((file, index) => (
                            <div key={index} className="file-preview">
                              <div className="flex items-center gap-2">
                                <FileCheck className="h-4 w-4 text-green-500" />
                                <span className="text-sm truncate flex-1">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatFileSize(file.size)}
                                </span>
                              </div>
                            </div>
                          ))}
                          {selectedFiles[key].length > 3 && (
                            <div className="text-xs text-muted-foreground text-center">
                              +{selectedFiles[key].length - 3} more files
                            </div>
                          )}
                        </div>
                      )}

                      {/* Upload Area */}
                      <div
                        className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                        onDragOver={(e) => handleDragOver(e, key)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, key)}
                      >
                        <div className="floating">
                          <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                        </div>
                        <h3 className="font-semibold mb-2">Upload PDF for {type.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Drag & drop your PDF files with data tables or charts
                        </p>
                        <input
                          ref={el => fileInputRefs.current[key] = el}
                          type="file"
                          multiple
                          className="hidden"
                          id={`file-${key}`}
                          accept=".pdf"
                          onChange={(e) => handleFileSelect(e, key)}
                        />
                        <Button 
                          variant="outline"
                          onClick={() => document.getElementById(`file-${key}`)?.click()}
                          className="transition-all duration-200 hover:scale-105"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Select PDF Files
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Table className="h-4 w-4 text-blue-500" />
                        <span>Auto table detection</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Database className="h-4 w-4 text-green-500" />
                        <span>Smart data extraction</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <BarChart3 className="h-4 w-4 text-purple-500" />
                        <span>Multiple chart types</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Image className="h-4 w-4 text-orange-500" />
                        <span>High-quality output</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Zap className="h-4 w-4 text-yellow-500" />
                        <span>Interactive charts</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        Processing Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Data extraction:</span>
                        <span className="text-muted-foreground">5-10 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Chart generation:</span>
                        <span className="text-muted-foreground">3-8 seconds</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Advanced charts:</span>
                        <span className="text-muted-foreground">10-20 seconds</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Supported Data Types</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-sm">• Financial tables</div>
                      <div className="text-sm">• Statistical data</div>
                      <div className="text-sm">• Survey results</div>
                      <div className="text-sm">• Performance metrics</div>
                      <div className="text-sm">• Time series data</div>
                      <div className="text-sm">• Categorical data</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Visualization Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Visualization Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your data visualization generation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {chartTypes[job.chartType as keyof typeof chartTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.dataPoints && (
                            <span>{job.dataPoints} data points</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            const chartName = chartTypes[job.chartType as keyof typeof chartTypes]?.title.toLowerCase().replace(/\s+/g, '-');
                            const extension = getFileExtension(job.settings?.outputFormat || 'png');
                            link.download = `${chartName}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${extension}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Visualization downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'extracting' || job.status === 'generating') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'extracting' && 'Extracting data...'}
                          {job.status === 'generating' && 'Generating charts...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Visualization Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}