import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  Globe, 
  Download,
  FileText,
  Code,
  Layout,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  FileCheck,
  Zap,
  Target,
  Clock,
  Monitor,
  Smartphone
} from 'lucide-react';
import { toast } from 'sonner';

interface WebGenJob {
  id: string;
  fileName: string;
  fileSize: number;
  outputType: string;
  status: 'uploading' | 'converting' | 'generating' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  result?: string;
  estimatedTime?: number;
  actualTime?: number;
  pages?: number;
}

const outputTypes = {
  html: {
    title: 'HTML Website',
    icon: Globe,
    color: 'bg-blue-500',
    description: 'Convert PDF to responsive HTML website',
    features: ['Responsive design', 'CSS styling', 'Interactive elements', 'SEO optimized']
  },
  markdown: {
    title: 'Markdown',
    icon: FileText,
    color: 'bg-green-500',
    description: 'Extract content as clean Markdown format',
    features: ['Clean formatting', 'GitHub compatible', 'Easy editing', 'Version control friendly']
  },
  webapp: {
    title: 'Web Application',
    icon: Code,
    color: 'bg-purple-500',
    description: 'Generate interactive web application',
    features: ['JavaScript functionality', 'Form handling', 'Dynamic content', 'Modern framework']
  },
  landing: {
    title: 'Landing Page',
    icon: Layout,
    color: 'bg-orange-500',
    description: 'Create marketing landing page from PDF',
    features: ['Call-to-action buttons', 'Lead capture forms', 'Mobile optimized', 'Fast loading']
  }
};

export default function WebGenerator() {
  const [jobs, setJobs] = useState<WebGenJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [webSettings, setWebSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for web generation'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, outputType: string): number => {
    const baseTime = {
      'html': 12,
      'markdown': 8,
      'webapp': 18,
      'landing': 15
    }[outputType] || 12;

    const sizeTime = Math.ceil(fileSize / (3 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, typeId: string) => {
    e.preventDefault();
    setDragOver(typeId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, outputType: string) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, outputType);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, outputType: string) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, outputType);
  };

  const handleFiles = (files: File[], outputType: string) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    setSelectedFiles(prev => ({
      ...prev,
      [outputType]: validFiles
    }));

    validFiles.forEach(file => {
      const jobId = Math.random().toString(36).substr(2, 9);
      const estimatedTime = estimateProcessingTime(file.size, outputType);
      
      const newJob: WebGenJob = {
        id: jobId,
        fileName: file.name,
        fileSize: file.size,
        outputType,
        status: 'uploading',
        progress: 0,
        estimatedTime
      };

      setJobs(prev => [...prev, newJob]);
      simulateWebGeneration(jobId, estimatedTime, outputType);
    });

    toast.success(`Started web generation for ${validFiles.length} file(s)`);
  };

  const simulateWebGeneration = (jobId: string, estimatedTime: number, outputType: string) => {
    const startTime = Date.now();
    
    // Simulate upload progress (20% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 200;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 10 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'converting', progress: 0 }
            : job
        ));

        // Simulate conversion (40% of total time)
        setTimeout(() => {
          setJobs(prev => prev.map(job => 
            job.id === jobId 
              ? { ...job, status: 'generating', progress: 0 }
              : job
          ));

          // Simulate generation (40% of total time)
          const generationDuration = estimatedTime * 400;
          const generationInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 3 + 1;
                if (newProgress >= 100) {
                  clearInterval(generationInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Generate result
                  const pages = Math.floor(Math.random() * 10) + 1;
                  const result = generateWebResult(outputType, pages);
                  const downloadBlob = createWebFile(outputType, job.fileName, pages);
                  const downloadUrl = URL.createObjectURL(downloadBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    result: getWebResultSummary(outputType, pages),
                    pages
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, generationDuration / 50);
        }, estimatedTime * 400);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const generateWebResult = (outputType: string, pages: number): string => {
    switch (outputType) {
      case 'html':
        return generateHTMLResult(pages);
      case 'markdown':
        return generateMarkdownResult(pages);
      case 'webapp':
        return generateWebAppResult(pages);
      case 'landing':
        return generateLandingResult(pages);
      default:
        return 'Web generation completed successfully';
    }
  };

  const generateHTMLResult = (pages: number): string => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generated Website</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; line-height: 1.6; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { background: #333; color: white; padding: 1rem; margin-bottom: 2rem; }
        .content { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .page { margin-bottom: 3rem; padding-bottom: 2rem; border-bottom: 1px solid #eee; }
        .responsive { width: 100%; height: auto; }
        @media (max-width: 768px) { .container { padding: 10px; } }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Generated Website from PDF</h1>
            <p>Responsive HTML conversion with ${pages} pages</p>
        </header>
        <main class="content">
            ${Array.from({length: pages}, (_, i) => `
            <section class="page">
                <h2>Page ${i + 1} Content</h2>
                <p>This is the converted content from page ${i + 1} of your PDF document. The content has been structured and formatted for web presentation.</p>
                <p>Features include responsive design, clean typography, and optimized loading performance.</p>
            </section>
            `).join('')}
        </main>
    </div>
</body>
</html>`;
  };

  const generateMarkdownResult = (pages: number): string => {
    let markdown = `# Generated Markdown Document\n\n`;
    markdown += `**Source:** PDF Document\n`;
    markdown += `**Pages:** ${pages}\n`;
    markdown += `**Generated:** ${new Date().toLocaleString()}\n\n`;
    markdown += `---\n\n`;
    
    for (let i = 1; i <= pages; i++) {
      markdown += `## Page ${i}\n\n`;
      markdown += `This is the content extracted from page ${i} of your PDF document. The text has been cleaned and formatted as Markdown for easy editing and version control.\n\n`;
      markdown += `### Key Points\n\n`;
      markdown += `- Clean formatting preserved\n`;
      markdown += `- Headings properly structured\n`;
      markdown += `- Lists and formatting maintained\n`;
      markdown += `- Ready for GitHub, GitLab, or any Markdown editor\n\n`;
      if (i < pages) markdown += `---\n\n`;
    }
    
    return markdown;
  };

  const generateWebAppResult = (pages: number): string => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF Web Application</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .app { min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { background: #2563eb; color: white; padding: 1rem 2rem; }
        .main { flex: 1; padding: 2rem; }
        .sidebar { width: 250px; background: white; padding: 1rem; border-radius: 8px; margin-right: 2rem; }
        .content { flex: 1; background: white; padding: 2rem; border-radius: 8px; }
        .btn { background: #2563eb; color: white; padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #1d4ed8; }
    </style>
</head>
<body>
    <div class="app">
        <nav class="navbar">
            <h1>PDF Web Application</h1>
            <p>${pages} pages converted to interactive web app</p>
        </nav>
        <div class="main" style="display: flex;">
            <aside class="sidebar">
                <h3>Navigation</h3>
                <ul style="list-style: none; padding-top: 1rem;">
                    ${Array.from({length: pages}, (_, i) => `<li style="margin-bottom: 0.5rem;"><a href="#page${i+1}" style="text-decoration: none; color: #2563eb;">Page ${i+1}</a></li>`).join('')}
                </ul>
            </aside>
            <main class="content">
                <h2>Interactive PDF Content</h2>
                <p>This web application provides an interactive interface for your PDF content with navigation, search, and dynamic features.</p>
                <button class="btn" onclick="alert('Interactive feature activated!')">Try Interactive Feature</button>
            </main>
        </div>
    </div>
    <script>
        // Interactive functionality
        document.addEventListener('DOMContentLoaded', function() {
            console.log('PDF Web App loaded with ${pages} pages');
        });
    </script>
</body>
</html>`;
  };

  const generateLandingResult = (pages: number): string => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Arial', sans-serif; line-height: 1.6; }
        .hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 4rem 2rem; text-align: center; }
        .hero h1 { font-size: 3rem; margin-bottom: 1rem; }
        .hero p { font-size: 1.2rem; margin-bottom: 2rem; }
        .cta-btn { background: #ff6b6b; color: white; padding: 1rem 2rem; border: none; border-radius: 50px; font-size: 1.1rem; cursor: pointer; }
        .cta-btn:hover { background: #ff5252; transform: translateY(-2px); }
        .features { padding: 4rem 2rem; max-width: 1200px; margin: 0 auto; }
        .feature-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }
        .feature { text-align: center; padding: 2rem; background: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <section class="hero">
        <h1>Your PDF Content, Beautifully Presented</h1>
        <p>Professional landing page generated from your ${pages}-page PDF document</p>
        <button class="cta-btn" onclick="alert('Lead captured!')">Get Started Today</button>
    </section>
    
    <section class="features">
        <div class="feature-grid">
            <div class="feature">
                <h3>Fast Loading</h3>
                <p>Optimized for speed and performance across all devices</p>
            </div>
            <div class="feature">
                <h3>Mobile Responsive</h3>
                <p>Perfect display on desktop, tablet, and mobile devices</p>
            </div>
            <div class="feature">
                <h3>SEO Optimized</h3>
                <p>Built with search engine optimization best practices</p>
            </div>
        </div>
    </section>
</body>
</html>`;
  };

  const createWebFile = (outputType: string, fileName: string, pages: number): Blob => {
    const result = generateWebResult(outputType, pages);
    
    switch (outputType) {
      case 'html':
      case 'webapp':
      case 'landing':
        return new Blob([result], { type: 'text/html' });
      case 'markdown':
        return new Blob([result], { type: 'text/markdown' });
      default:
        return new Blob([result], { type: 'text/plain' });
    }
  };

  const getWebResultSummary = (outputType: string, pages: number): string => {
    const typeName = outputTypes[outputType as keyof typeof outputTypes]?.title;
    return `${typeName} generated successfully from ${pages} pages. Ready for deployment and customization.`;
  };

  const clearFiles = (typeId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [typeId]: []
    }));
    if (fileInputRefs.current[typeId]) {
      fileInputRefs.current[typeId]!.value = '';
    }
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateWebGeneration(jobId, job.estimatedTime || 12, job.outputType);
    }
  };

  const getStatusIcon = (status: WebGenJob['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 animate-pulse" />;
      case 'converting':
        return <FileText className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'generating':
        return <Globe className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: WebGenJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'converting':
        return 'Converting Content...';
      case 'generating':
        return 'Generating Web Files...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const getFileExtension = (outputType: string): string => {
    switch (outputType) {
      case 'html':
      case 'webapp':
      case 'landing':
        return 'html';
      case 'markdown':
        return 'md';
      default:
        return 'html';
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Globe className="h-8 w-8 text-primary floating" />
            Web Generator
          </h1>
          <p className="text-muted-foreground">
            Convert PDF documents to websites, web applications, and markdown
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {Object.entries(outputTypes).map(([key, type]) => (
            <Card key={key} className="conversion-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <type.icon className="h-5 w-5" />
                  {type.title}
                </CardTitle>
                <CardDescription>{type.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Features */}
                <div>
                  <h4 className="font-medium mb-2">Features:</h4>
                  <div className="space-y-1">
                    {type.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* File Preview */}
                {selectedFiles[key]?.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Selected Files:</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => clearFiles(key)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                    {selectedFiles[key].slice(0, 3).map((file, index) => (
                      <div key={index} className="file-preview">
                        <div className="flex items-center gap-2">
                          <FileCheck className="h-4 w-4 text-green-500" />
                          <span className="text-sm truncate flex-1">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatFileSize(file.size)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Upload Area */}
                <div
                  className={`upload-area ${dragOver === key ? 'dragover' : ''}`}
                  onDragOver={(e) => handleDragOver(e, key)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, key)}
                >
                  <div className="floating">
                    <type.icon className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold mb-2">Generate {type.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Upload PDF to convert to {type.title.toLowerCase()}
                  </p>
                  <input
                    ref={el => fileInputRefs.current[key] = el}
                    type="file"
                    multiple
                    className="hidden"
                    id={`file-${key}`}
                    accept=".pdf"
                    onChange={(e) => handleFileSelect(e, key)}
                  />
                  <Button 
                    variant="outline"
                    onClick={() => document.getElementById(`file-${key}`)?.click()}
                    className="transition-all duration-200 hover:scale-105"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select PDF Files
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Generation Jobs */}
        {jobs.length > 0 && (
          <Card className="bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Web Generation Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your web generation tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <Globe className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">
                            {outputTypes[job.outputType as keyof typeof outputTypes]?.title}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Size: {formatFileSize(job.fileSize)}</span>
                          {job.pages && (
                            <span>{job.pages} pages processed</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl!;
                            const typeName = outputTypes[job.outputType as keyof typeof outputTypes]?.title.toLowerCase().replace(/\s+/g, '-');
                            const extension = getFileExtension(job.outputType);
                            link.download = `${typeName}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.${extension}`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success('Web files downloaded!');
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'converting' || job.status === 'generating') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>
                          {job.status === 'uploading' && 'Uploading file...'}
                          {job.status === 'converting' && 'Converting content...'}
                          {job.status === 'generating' && 'Generating web files...'}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {job.result && (
                    <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">Generation Complete</p>
                          <p className="text-sm text-green-700 dark:text-green-300">{job.result}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Features Info */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Web Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Monitor className="h-4 w-4 text-blue-500" />
                <span>Responsive design</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Smartphone className="h-4 w-4 text-green-500" />
                <span>Mobile optimized</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Fast loading</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Code className="h-4 w-4 text-purple-500" />
                <span>Clean code</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Processing Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>HTML website:</span>
                <span className="text-muted-foreground">10-18 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Markdown:</span>
                <span className="text-muted-foreground">6-12 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Web application:</span>
                <span className="text-muted-foreground">15-25 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Landing page:</span>
                <span className="text-muted-foreground">12-20 seconds</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Output Files</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm">• HTML files with CSS</div>
              <div className="text-sm">• Responsive layouts</div>
              <div className="text-sm">• Interactive elements</div>
              <div className="text-sm">• SEO optimized</div>
              <div className="text-sm">• Ready for deployment</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TooltipProvider>
  );
}