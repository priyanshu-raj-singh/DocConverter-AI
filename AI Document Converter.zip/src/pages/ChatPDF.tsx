import { useState, useCallback, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  Upload, 
  MessageCircle, 
  Send,
  FileText,
  Bot,
  User,
  Search,
  BookOpen,
  HelpCircle,
  Lightbulb,
  RefreshCw,
  X,
  FileCheck,
  Zap,
  Brain,
  Target,
  Clock
} from 'lucide-react';
import { toast } from 'sonner';

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  pageReference?: number;
  confidence?: number;
}

interface UploadedPDF {
  id: string;
  name: string;
  size: number;
  uploadedAt: Date;
  status: 'processing' | 'ready' | 'error';
  pageCount?: number;
}

const quickQuestions = [
  "What is the main topic of this document?",
  "Summarize the key points",
  "What are the important dates mentioned?",
  "List all the numerical data",
  "What conclusions are drawn?",
  "Explain the methodology used",
  "What are the recommendations?",
  "Who are the key people mentioned?"
];

const chatExamples = [
  {
    category: "Content Analysis",
    questions: [
      "What is the main argument in this document?",
      "Summarize chapter 3 in bullet points",
      "What evidence supports the conclusion?"
    ]
  },
  {
    category: "Data Extraction",
    questions: [
      "List all the statistics mentioned",
      "What are the financial figures?",
      "Extract all contact information"
    ]
  },
  {
    category: "Explanation",
    questions: [
      "Explain this concept in simple terms",
      "What does this technical term mean?",
      "How does this process work?"
    ]
  },
  {
    category: "Search & Find",
    questions: [
      "Find information about [topic]",
      "Where is [specific term] mentioned?",
      "Show me all references to [keyword]"
    ]
  }
];

export default function ChatPDF() {
  const [uploadedPDFs, setUploadedPDFs] = useState<UploadedPDF[]>([]);
  const [selectedPDF, setSelectedPDF] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported for chat'
      };
    }

    if (file.size > 50 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 50MB limit'
      };
    }

    return { valid: true };
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  };

  const handleFiles = (files: File[]) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    validFiles.forEach(file => {
      const pdfId = Math.random().toString(36).substr(2, 9);
      const newPDF: UploadedPDF = {
        id: pdfId,
        name: file.name,
        size: file.size,
        uploadedAt: new Date(),
        status: 'processing'
      };

      setUploadedPDFs(prev => [...prev, newPDF]);
      
      // Simulate processing
      setTimeout(() => {
        setUploadedPDFs(prev => prev.map(pdf => 
          pdf.id === pdfId 
            ? { ...pdf, status: 'ready', pageCount: Math.floor(Math.random() * 50) + 10 }
            : pdf
        ));
        
        // Auto-select if it's the first PDF
        if (uploadedPDFs.length === 0) {
          setSelectedPDF(pdfId);
          addBotMessage("Hello! I've analyzed your PDF and I'm ready to answer questions about it. What would you like to know?");
        }
      }, 3000);
    });

    toast.success(`Processing ${validFiles.length} PDF(s)...`);
  };

  const addBotMessage = (content: string, pageReference?: number, confidence?: number) => {
    const botMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'bot',
      content,
      timestamp: new Date(),
      pageReference,
      confidence
    };
    setMessages(prev => [...prev, botMessage]);
  };

  const addUserMessage = (content: string) => {
    const userMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'user',
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
  };

  const generateBotResponse = (userQuestion: string): { content: string; pageReference?: number; confidence?: number } => {
    const question = userQuestion.toLowerCase();
    
    if (question.includes('summary') || question.includes('summarize')) {
      return {
        content: "Based on my analysis of the document, here's a summary:\n\n• The document discusses key business strategies and market analysis\n• It presents data from Q3 2024 showing 15% growth in revenue\n• Main recommendations include expanding digital presence and optimizing operations\n• The conclusion emphasizes the importance of customer-centric approaches\n\nWould you like me to elaborate on any specific section?",
        pageReference: 1,
        confidence: 92
      };
    }
    
    if (question.includes('main topic') || question.includes('about')) {
      return {
        content: "This document appears to be a comprehensive business report focusing on market analysis and strategic planning. The main topics covered include:\n\n1. Market trends and competitive landscape\n2. Financial performance metrics\n3. Strategic recommendations for growth\n4. Implementation roadmap\n\nThe document spans multiple sections with detailed analysis and supporting data.",
        pageReference: 2,
        confidence: 95
      };
    }
    
    if (question.includes('data') || question.includes('numbers') || question.includes('statistics')) {
      return {
        content: "I found several key numerical data points in the document:\n\n• Revenue: $2.4M (15% increase from previous quarter)\n• Customer acquisition: 1,250 new customers\n• Market share: 23.5%\n• Employee count: 145 people\n• Customer satisfaction: 4.2/5.0\n• Operating margin: 18.3%\n\nWould you like me to explain any of these metrics in more detail?",
        pageReference: 5,
        confidence: 88
      };
    }
    
    if (question.includes('conclusion') || question.includes('recommendation')) {
      return {
        content: "The document concludes with several key recommendations:\n\n1. **Digital Transformation**: Invest in digital infrastructure to improve customer experience\n2. **Market Expansion**: Target emerging markets in Southeast Asia\n3. **Operational Efficiency**: Implement automation to reduce costs by 12%\n4. **Talent Development**: Establish training programs for skill enhancement\n5. **Sustainability**: Adopt eco-friendly practices to meet 2025 goals\n\nThese recommendations are backed by detailed analysis and projected ROI calculations.",
        pageReference: 12,
        confidence: 90
      };
    }
    
    if (question.includes('page') && /\d+/.test(question)) {
      const pageNum = question.match(/\d+/)?.[0];
      return {
        content: `Page ${pageNum} contains information about market analysis and competitive positioning. This section discusses:\n\n• Competitor comparison matrix\n• Market segmentation analysis\n• Customer behavior patterns\n• Pricing strategy recommendations\n\nThe data on this page supports the overall strategic direction outlined in the executive summary.`,
        pageReference: parseInt(pageNum || '1'),
        confidence: 85
      };
    }
    
    if (question.includes('explain') || question.includes('what does') || question.includes('meaning')) {
      return {
        content: "I'd be happy to explain that concept! Based on the context in your document:\n\nThis term refers to a strategic business approach that focuses on understanding and meeting customer needs through data-driven insights. The document explains it as a methodology that combines:\n\n• Customer feedback analysis\n• Market research data\n• Behavioral pattern recognition\n• Predictive analytics\n\nThis approach helps businesses make informed decisions and improve customer satisfaction.",
        pageReference: 7,
        confidence: 87
      };
    }
    
    // Default response
    return {
      content: "I understand your question about the document. Based on my analysis, I can provide relevant information, but I'd need a bit more context to give you the most accurate answer.\n\nCould you please:\n• Be more specific about what section you're interested in\n• Mention any particular page numbers\n• Clarify what type of information you're looking for\n\nI'm here to help you understand any part of this document!",
      confidence: 75
    };
  };

  const handleSendMessage = () => {
    if (!currentMessage.trim() || !selectedPDF) return;
    
    addUserMessage(currentMessage);
    setCurrentMessage('');
    setIsTyping(true);
    
    // Simulate AI processing time
    setTimeout(() => {
      const response = generateBotResponse(currentMessage);
      addBotMessage(response.content, response.pageReference, response.confidence);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleQuickQuestion = (question: string) => {
    if (!selectedPDF) {
      toast.error('Please upload and select a PDF first');
      return;
    }
    setCurrentMessage(question);
  };

  const removePDF = (pdfId: string) => {
    setUploadedPDFs(prev => prev.filter(pdf => pdf.id !== pdfId));
    if (selectedPDF === pdfId) {
      setSelectedPDF(null);
      setMessages([]);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <MessageCircle className="h-8 w-8 text-primary floating" />
            Chat with PDF
          </h1>
          <p className="text-muted-foreground">
            Upload your PDF and have intelligent conversations about its content
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* PDF Upload & Management */}
          <div className="lg:col-span-1 space-y-6">
            {/* Upload Area */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Upload PDF
                </CardTitle>
                <CardDescription>
                  Upload PDFs to start chatting
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`upload-area ${dragOver ? 'dragover' : ''}`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  <div className="floating">
                    <FileText className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Drag & drop PDF files here
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    accept=".pdf"
                    onChange={handleFileSelect}
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="transition-all duration-200 hover:scale-105"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select Files
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Uploaded PDFs */}
            {uploadedPDFs.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Your PDFs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {uploadedPDFs.map((pdf) => (
                    <div 
                      key={pdf.id} 
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        selectedPDF === pdf.id 
                          ? 'border-primary bg-primary/5' 
                          : 'hover:border-primary/50'
                      }`}
                      onClick={() => pdf.status === 'ready' && setSelectedPDF(pdf.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <FileCheck className={`h-4 w-4 ${
                              pdf.status === 'ready' ? 'text-green-500' : 
                              pdf.status === 'processing' ? 'text-yellow-500' : 'text-red-500'
                            }`} />
                            <span className="text-sm font-medium truncate">{pdf.name}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{formatFileSize(pdf.size)}</span>
                            {pdf.pageCount && <span>• {pdf.pageCount} pages</span>}
                            {pdf.status === 'processing' && (
                              <RefreshCw className="h-3 w-3 animate-spin" />
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            removePDF(pdf.id);
                          }}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      {pdf.status === 'ready' && selectedPDF === pdf.id && (
                        <Badge variant="default" className="mt-2 text-xs">
                          Active Chat
                        </Badge>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Quick Questions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  Quick Questions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {quickQuestions.slice(0, 6).map((question, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start h-auto p-2 text-left"
                    onClick={() => handleQuickQuestion(question)}
                    disabled={!selectedPDF}
                  >
                    <span className="text-xs">{question}</span>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Chat Interface
                  {selectedPDF && (
                    <Badge variant="outline" className="ml-auto">
                      {uploadedPDFs.find(pdf => pdf.id === selectedPDF)?.name}
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  {!selectedPDF ? (
                    <div className="flex items-center justify-center h-full text-center">
                      <div>
                        <MessageCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="font-semibold mb-2">No PDF Selected</h3>
                        <p className="text-sm text-muted-foreground">
                          Upload and select a PDF to start chatting
                        </p>
                      </div>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-center">
                      <div>
                        <Bot className="h-12 w-12 mx-auto mb-4 text-primary" />
                        <h3 className="font-semibold mb-2">Ready to Chat!</h3>
                        <p className="text-sm text-muted-foreground">
                          Ask me anything about your PDF
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex gap-3 ${
                            message.type === 'user' ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          {message.type === 'bot' && (
                            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                              <Bot className="h-4 w-4 text-white" />
                            </div>
                          )}
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              message.type === 'user'
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted'
                            }`}
                          >
                            <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                            <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                              <span>{formatTime(message.timestamp)}</span>
                              {message.type === 'bot' && (
                                <div className="flex items-center gap-2">
                                  {message.pageReference && (
                                    <Badge variant="secondary" className="text-xs">
                                      Page {message.pageReference}
                                    </Badge>
                                  )}
                                  {message.confidence && (
                                    <Badge variant="outline" className="text-xs">
                                      {message.confidence}% confident
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                          {message.type === 'user' && (
                            <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                              <User className="h-4 w-4" />
                            </div>
                          )}
                        </div>
                      ))}
                      {isTyping && (
                        <div className="flex gap-3 justify-start">
                          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                            <Bot className="h-4 w-4 text-white" />
                          </div>
                          <div className="bg-muted rounded-lg p-3">
                            <div className="flex items-center gap-1">
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </ScrollArea>

                {/* Input Area */}
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder={selectedPDF ? "Ask a question about your PDF..." : "Select a PDF first"}
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={!selectedPDF || isTyping}
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!currentMessage.trim() || !selectedPDF || isTyping}
                      size="icon"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Examples & Features */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  AI Capabilities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Search className="h-4 w-4 text-blue-500" />
                  <span>Semantic search</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <BookOpen className="h-4 w-4 text-green-500" />
                  <span>Content explanation</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Target className="h-4 w-4 text-purple-500" />
                  <span>Page-specific answers</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  <span>Instant responses</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <HelpCircle className="h-4 w-4 text-orange-500" />
                  <span>Context understanding</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <HelpCircle className="h-5 w-5" />
                  Example Questions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {chatExamples.map((category, index) => (
                  <div key={index}>
                    <h4 className="font-medium text-sm mb-2">{category.category}</h4>
                    <div className="space-y-1">
                      {category.questions.map((question, qIndex) => (
                        <Button
                          key={qIndex}
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start h-auto p-2 text-left"
                          onClick={() => handleQuickQuestion(question)}
                          disabled={!selectedPDF}
                        >
                          <span className="text-xs text-muted-foreground">{question}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Response Time
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Simple questions:</span>
                  <span className="text-muted-foreground">1-2 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Complex analysis:</span>
                  <span className="text-muted-foreground">3-5 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Data extraction:</span>
                  <span className="text-muted-foreground">2-4 seconds</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}