import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Download,
  FileText,
  Calendar,
  Clock,
  Search,
  Filter,
  Trash2,
  Eye,
  Share
} from 'lucide-react';
import { toast } from 'sonner';

interface HistoryItem {
  id: string;
  fileName: string;
  originalName: string;
  operation: string;
  status: 'completed' | 'failed';
  createdAt: Date;
  fileSize: string;
  downloadUrl?: string;
}

// Mock history data
const mockHistory: HistoryItem[] = [
  {
    id: '1',
    fileName: 'annual-report-2024.pdf',
    originalName: 'annual-report-2024.docx',
    operation: 'Word to PDF',
    status: 'completed',
    createdAt: new Date('2024-01-15T10:30:00'),
    fileSize: '2.4 MB',
    downloadUrl: '#'
  },
  {
    id: '2',
    fileName: 'presentation-slides.pdf',
    originalName: 'presentation-slides.pptx',
    operation: 'PowerPoint to PDF',
    status: 'completed',
    createdAt: new Date('2024-01-14T15:45:00'),
    fileSize: '5.1 MB',
    downloadUrl: '#'
  },
  {
    id: '3',
    fileName: 'financial-data.xlsx',
    originalName: 'financial-report.pdf',
    operation: 'PDF to Excel',
    status: 'completed',
    createdAt: new Date('2024-01-14T09:20:00'),
    fileSize: '1.8 MB',
    downloadUrl: '#'
  },
  {
    id: '4',
    fileName: 'contract-translated.pdf',
    originalName: 'contract-original.pdf',
    operation: 'AI Translation',
    status: 'completed',
    createdAt: new Date('2024-01-13T14:15:00'),
    fileSize: '3.2 MB',
    downloadUrl: '#'
  },
  {
    id: '5',
    fileName: 'merged-documents.pdf',
    originalName: 'multiple-files.pdf',
    operation: 'Merge PDFs',
    status: 'completed',
    createdAt: new Date('2024-01-12T11:30:00'),
    fileSize: '8.7 MB',
    downloadUrl: '#'
  },
  {
    id: '6',
    fileName: 'compressed-manual.pdf',
    originalName: 'user-manual.pdf',
    operation: 'Compress PDF',
    status: 'completed',
    createdAt: new Date('2024-01-11T16:45:00'),
    fileSize: '1.2 MB',
    downloadUrl: '#'
  }
];

export default function History() {
  const [history, setHistory] = useState<HistoryItem[]>(mockHistory);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'completed' | 'failed'>('all');

  const filteredHistory = history.filter(item => {
    const matchesSearch = item.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.originalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.operation.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === 'all' || item.status === filterStatus;
    
    return matchesSearch && matchesFilter;
  });

  const handleDownload = async (item: HistoryItem) => {
    try {
      // Create a sample file based on the operation type
      let blob: Blob;
      
      if (item.operation.includes('AI')) {
        blob = downloadUtils.createAIEditedPDF(item.originalName, 'Sample AI operation');
      } else if (item.operation.includes('PDF to Word')) {
        blob = downloadUtils.createWord(item.originalName);
      } else if (item.operation.includes('PDF to Excel')) {
        blob = downloadUtils.createExcel(item.originalName);
      } else if (item.operation.includes('PDF to PowerPoint')) {
        blob = downloadUtils.createPowerPoint(item.originalName);
      } else if (item.operation.includes('Image')) {
        blob = await downloadUtils.createImage(item.originalName);
      } else {
        blob = downloadUtils.createPDF(item.originalName, `Sample content for ${item.operation}`);
      }
      
      // Download the file
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = item.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success(`Downloaded ${item.fileName}`);
    } catch (error) {
      toast.error('Failed to download file');
    }
  };

  const handleDelete = (itemId: string) => {
    setHistory(prev => prev.filter(item => item.id !== itemId));
    toast.success('File deleted from history');
  };

  const handleShare = (item: HistoryItem) => {
    navigator.clipboard.writeText(window.location.origin + '/download/' + item.id);
    toast.success('Download link copied to clipboard');
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getOperationColor = (operation: string) => {
    if (operation.includes('AI')) return 'bg-purple-500';
    if (operation.includes('PDF')) return 'bg-red-500';
    if (operation.includes('Word')) return 'bg-blue-500';
    if (operation.includes('Excel')) return 'bg-green-500';
    if (operation.includes('PowerPoint')) return 'bg-orange-500';
    return 'bg-gray-500';
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Conversion History</h1>
        <p className="text-muted-foreground">
          View and manage your document conversion history
        </p>
      </div>

      {/* Search and Filter */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search files, operations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterStatus === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterStatus('all')}
              >
                All
              </Button>
              <Button
                variant={filterStatus === 'completed' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterStatus('completed')}
              >
                Completed
              </Button>
              <Button
                variant={filterStatus === 'failed' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterStatus('failed')}
              >
                Failed
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* History List */}
      {filteredHistory.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No files found</h3>
            <p className="text-muted-foreground">
              {searchTerm || filterStatus !== 'all' 
                ? 'Try adjusting your search or filter criteria'
                : 'Start converting documents to see your history here'
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredHistory.map((item) => (
            <Card key={item.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                      <FileText className="h-6 w-6 text-muted-foreground" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate">{item.fileName}</h3>
                        <Badge 
                          variant="secondary" 
                          className={`${getOperationColor(item.operation)} text-white`}
                        >
                          {item.operation}
                        </Badge>
                        <Badge 
                          variant={item.status === 'completed' ? 'default' : 'destructive'}
                        >
                          {item.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          {item.originalName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {formatDate(item.createdAt)}
                        </span>
                        <span>{item.fileSize}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {item.status === 'completed' && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleShare(item)}
                        >
                          <Share className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleDownload(item)}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Statistics */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Statistics</CardTitle>
          <CardDescription>Your document conversion summary</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {history.filter(item => item.status === 'completed').length}
              </div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {history.filter(item => item.status === 'failed').length}
              </div>
              <div className="text-sm text-muted-foreground">Failed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {history.length}
              </div>
              <div className="text-sm text-muted-foreground">Total Files</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {(history.reduce((acc, item) => acc + parseFloat(item.fileSize), 0)).toFixed(1)}
              </div>
              <div className="text-sm text-muted-foreground">MB Processed</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}