import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Upload, Download, Eye, EyeOff, AlertTriangle, CheckCircle, Clock, Target } from 'lucide-react';
import { toast } from 'sonner';

export default function RedactionTool() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
    toast.success(`Selected ${files.length} file(s) for redaction`);
  };

  return (
    <div className="container py-8">
      <div className="mb-8 slide-up">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Shield className="h-8 w-8 text-primary floating" />
          Redaction Tool
        </h1>
        <p className="text-muted-foreground">
          Automatically detect and redact sensitive information from PDF documents
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="conversion-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Smart Redaction
            </CardTitle>
            <CardDescription>AI-powered detection of sensitive information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="upload-area">
              <div className="floating">
                <Shield className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Upload PDFs for Redaction</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Automatically detect and redact sensitive information
              </p>
              <input
                type="file"
                multiple
                className="hidden"
                id="redaction-files"
                accept=".pdf"
                onChange={handleFileSelect}
              />
              <Button 
                variant="outline"
                onClick={() => document.getElementById('redaction-files')?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Select PDF Files
              </Button>
            </div>

            {selectedFiles.length > 0 && (
              <div className="space-y-2">
                <span className="text-sm font-medium">Selected Files:</span>
                {selectedFiles.map((file, index) => (
                  <div key={index} className="file-preview">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span className="text-sm truncate flex-1">{file.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Detection Types
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <EyeOff className="h-4 w-4 text-red-500" />
                <span>Social Security Numbers</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <EyeOff className="h-4 w-4 text-red-500" />
                <span>Credit Card Numbers</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <EyeOff className="h-4 w-4 text-red-500" />
                <span>Email Addresses</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <EyeOff className="h-4 w-4 text-red-500" />
                <span>Phone Numbers</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <EyeOff className="h-4 w-4 text-red-500" />
                <span>Names & Addresses</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Processing Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Small PDFs:</span>
                <span className="text-muted-foreground">5-10 seconds</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Large PDFs:</span>
                <span className="text-muted-foreground">15-30 seconds</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}