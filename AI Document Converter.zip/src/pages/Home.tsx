import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FileText, 
  Wand2, 
  Settings, 
  ArrowRight,
  Upload,
  Download,
  Zap,
  Shield
} from 'lucide-react';

const features = [
  {
    icon: FileText,
    title: 'Universal Converter',
    description: 'Convert between PDF, Word, Excel, PowerPoint, images, and more formats instantly.',
    href: '/converter',
  },
  {
    icon: Wand2,
    title: 'AI PDF Editor',
    description: 'Edit PDFs with natural language prompts. Remove, modify, or add content effortlessly.',
    href: '/ai-editor',
  },
  {
    icon: Settings,
    title: 'PDF Tools',
    description: 'Merge, split, compress, protect, and manipulate PDFs with professional tools.',
    href: '/pdf-tools',
  },
];

const stats = [
  { label: 'Supported Formats', value: '15+' },
  { label: 'Files Processed', value: '1M+' },
  { label: 'Happy Users', value: '50K+' },
  { label: 'Uptime', value: '99.9%' },
];

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 px-4 gradient-hero text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Convert & Edit Documents
            <br />
            <span className="text-white/90">with AI Power</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto">
            Transform any document format instantly. Edit PDFs with natural language. 
            Professional tools for all your document needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
              <Link to="/converter">
                <Upload className="mr-2 h-5 w-5" />
                Start Converting
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
              <Link to="/ai-editor">
                <Wand2 className="mr-2 h-5 w-5" />
                Try AI Editor
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need for Documents
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From simple conversions to AI-powered editing, we've got all your document processing needs covered.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card key={feature.title} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-1">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg gradient-primary flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="ghost" className="group-hover:text-primary" asChild>
                      <Link to={feature.href}>
                        Get Started
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 bg-accent/50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How It Works
            </h2>
            <p className="text-xl text-muted-foreground">
              Simple, fast, and secure document processing in three steps.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-6">
                <Upload className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">1. Upload Your File</h3>
              <p className="text-muted-foreground">
                Drag and drop or click to upload your document. We support all major formats.
              </p>
            </div>

            <div className="text-center">
              <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-6">
                <Zap className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">2. Choose Your Action</h3>
              <p className="text-muted-foreground">
                Convert to another format, edit with AI, or use our professional PDF tools.
              </p>
            </div>

            <div className="text-center">
              <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-6">
                <Download className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">3. Download Result</h3>
              <p className="text-muted-foreground">
                Get your processed file instantly. All files are automatically deleted after 24 hours.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Security & Privacy */}
      <section className="py-20 px-4">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <div className="h-16 w-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-6">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Your Privacy is Our Priority
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              All files are processed securely and automatically deleted after 24 hours. 
              We never store or share your documents. Your data stays private, always.
            </p>
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div className="p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">🔒 Encrypted Processing</h3>
                <p className="text-sm text-muted-foreground">
                  All uploads and processing happen over secure HTTPS connections.
                </p>
              </div>
              <div className="p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">🗑️ Auto-Delete</h3>
                <p className="text-sm text-muted-foreground">
                  Files are automatically deleted from our servers after 24 hours.
                </p>
              </div>
              <div className="p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">🚫 No Tracking</h3>
                <p className="text-sm text-muted-foreground">
                  We don't track, store, or analyze your document content.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 gradient-hero text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Documents?
          </h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Join thousands of users who trust DocConverter AI for their document processing needs.
          </p>
          <Button size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
            <Link to="/converter">
              <FileText className="mr-2 h-5 w-5" />
              Start Converting Now
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}