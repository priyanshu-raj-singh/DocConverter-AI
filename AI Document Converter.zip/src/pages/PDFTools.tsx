import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Slider } from '@/components/ui/slider';
import { downloadUtils } from '@/lib/downloadUtils';
import { 
  Upload, 
  Download,
  Scissors,
  Merge,
  Archive,
  Lock,
  Unlock,
  RotateCw,
  Image,
  FileText,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  X,
  Eye,
  Droplets,
  Info,
  Settings,
  Zap,
  Clock,
  FileCheck
} from 'lucide-react';
import { toast } from 'sonner';

interface PDFJob {
  id: string;
  fileName: string;
  fileSize: number;
  tool: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  settings?: any;
  estimatedTime?: number;
  actualTime?: number;
  outputSize?: number;
}

const pdfTools = [
  {
    id: 'merge',
    title: 'Merge PDFs',
    description: 'Combine multiple PDF files into one document with custom order',
    icon: Merge,
    color: 'bg-blue-500',
    category: 'organize',
    accuracy: 100,
    avgTime: '2-5 seconds',
    features: ['Custom page order', 'Bookmark preservation', 'Metadata merging'],
    multiFile: true
  },
  {
    id: 'split',
    title: 'Split PDF',
    description: 'Split PDF into separate pages or custom page ranges',
    icon: Scissors,
    color: 'bg-green-500',
    category: 'organize',
    accuracy: 100,
    avgTime: '1-3 seconds',
    features: ['Page ranges', 'Individual pages', 'Batch splitting'],
    multiFile: false
  },
  {
    id: 'compress',
    title: 'Compress PDF',
    description: 'Reduce PDF file size while maintaining optimal quality',
    icon: Archive,
    color: 'bg-orange-500',
    category: 'optimize',
    accuracy: 95,
    avgTime: '3-8 seconds',
    features: ['Smart compression', 'Quality levels', 'Image optimization'],
    multiFile: false
  },
  {
    id: 'protect',
    title: 'Protect PDF',
    description: 'Add password protection and set document permissions',
    icon: Lock,
    color: 'bg-red-500',
    category: 'security',
    accuracy: 100,
    avgTime: '1-2 seconds',
    features: ['Password protection', 'Print restrictions', 'Copy restrictions'],
    multiFile: false
  },
  {
    id: 'unlock',
    title: 'Unlock PDF',
    description: 'Remove password protection from PDF documents',
    icon: Unlock,
    color: 'bg-purple-500',
    category: 'security',
    accuracy: 98,
    avgTime: '1-2 seconds',
    features: ['Password removal', 'Permission clearing', 'Access restoration'],
    multiFile: false
  },
  {
    id: 'rotate',
    title: 'Rotate Pages',
    description: 'Rotate PDF pages to correct orientation with precision',
    icon: RotateCw,
    color: 'bg-indigo-500',
    category: 'edit',
    accuracy: 100,
    avgTime: '1-3 seconds',
    features: ['90° increments', 'Selective pages', 'Batch rotation'],
    multiFile: false
  },
  {
    id: 'extract-images',
    title: 'Extract Images',
    description: 'Extract all images from PDF with original quality',
    icon: Image,
    color: 'bg-pink-500',
    category: 'extract',
    accuracy: 95,
    avgTime: '2-6 seconds',
    features: ['High resolution', 'Multiple formats', 'Batch extraction'],
    multiFile: false
  },
  {
    id: 'watermark',
    title: 'Add Watermark',
    description: 'Add custom text or image watermarks with positioning',
    icon: Droplets,
    color: 'bg-cyan-500',
    category: 'edit',
    accuracy: 98,
    avgTime: '2-4 seconds',
    features: ['Text watermarks', 'Image watermarks', 'Position control'],
    multiFile: false
  },
  {
    id: 'ocr',
    title: 'OCR Text',
    description: 'Extract text from scanned PDFs with high accuracy',
    icon: Eye,
    color: 'bg-yellow-500',
    category: 'extract',
    accuracy: 92,
    avgTime: '5-15 seconds',
    features: ['Multi-language', 'Searchable PDFs', 'Text extraction'],
    multiFile: false
  }
];

export default function PDFTools() {
  const [jobs, setJobs] = useState<PDFJob[]>([]);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File[]}>({});
  const [toolSettings, setToolSettings] = useState<any>({});
  const fileInputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return {
        valid: false,
        error: 'Only PDF files are supported'
      };
    }

    if (file.size > 100 * 1024 * 1024) {
      return {
        valid: false,
        error: 'File size exceeds 100MB limit'
      };
    }

    return { valid: true };
  };

  const estimateProcessingTime = (fileSize: number, toolId: string, fileCount: number = 1): number => {
    const baseTime = {
      'merge': 2 + (fileCount * 0.5),
      'split': 1,
      'compress': 5,
      'protect': 1,
      'unlock': 1,
      'rotate': 1,
      'extract-images': 3,
      'watermark': 2,
      'ocr': 8
    }[toolId] || 3;

    const sizeTime = Math.ceil(fileSize / (10 * 1024 * 1024));
    return baseTime + sizeTime;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent, toolId: string) => {
    e.preventDefault();
    setDragOver(toolId);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, tool: any) => {
    e.preventDefault();
    setDragOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files, tool);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, tool: any) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files, tool);
  };

  const handleFiles = (files: File[], tool: any) => {
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length === 0) return;

    // Update selected files for preview
    setSelectedFiles(prev => ({
      ...prev,
      [tool.id]: validFiles
    }));

    // For merge tool, create one job for all files
    if (tool.id === 'merge' && validFiles.length > 1) {
      const jobId = Math.random().toString(36).substr(2, 9);
      const totalSize = validFiles.reduce((sum, file) => sum + file.size, 0);
      const estimatedTime = estimateProcessingTime(totalSize, tool.id, validFiles.length);
      
      const newJob: PDFJob = {
        id: jobId,
        fileName: `merged-${validFiles.length}-files.pdf`,
        fileSize: totalSize,
        tool: tool.title,
        status: 'uploading',
        progress: 0,
        estimatedTime,
        settings: toolSettings[tool.id] || {}
      };

      setJobs(prev => [...prev, newJob]);
      simulateProcessing(jobId, estimatedTime, totalSize * 0.8); // Merged file is usually smaller
    } else {
      // Create individual jobs for each file
      validFiles.forEach(file => {
        const jobId = Math.random().toString(36).substr(2, 9);
        const estimatedTime = estimateProcessingTime(file.size, tool.id);
        
        const newJob: PDFJob = {
          id: jobId,
          fileName: file.name,
          fileSize: file.size,
          tool: tool.title,
          status: 'uploading',
          progress: 0,
          estimatedTime,
          settings: toolSettings[tool.id] || {}
        };

        setJobs(prev => [...prev, newJob]);
        
        // Estimate output size based on tool
        let outputSize = file.size;
        if (tool.id === 'compress') outputSize *= 0.6;
        if (tool.id === 'protect' || tool.id === 'unlock') outputSize *= 1.02;
        if (tool.id === 'watermark') outputSize *= 1.1;
        
        simulateProcessing(jobId, estimatedTime, outputSize);
      });
    }

    toast.success(`Started ${tool.title.toLowerCase()} for ${validFiles.length} file(s)`);
  };

  const simulateProcessing = (jobId: string, estimatedTime: number, outputSize?: number) => {
    const startTime = Date.now();
    
    // Simulate upload progress (20% of total time)
    let progress = 0;
    const uploadDuration = estimatedTime * 200;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 15 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);
        
        setJobs(prev => prev.map(job => 
          job.id === jobId 
            ? { ...job, status: 'processing', progress: 0 }
            : job
        ));

        // Simulate processing (80% of total time)
        const processingDuration = estimatedTime * 800;
        setTimeout(() => {
          const processingInterval = setInterval(() => {
            setJobs(prev => prev.map(job => {
              if (job.id === jobId) {
                const newProgress = job.progress + Math.random() * 8 + 2;
                if (newProgress >= 100) {
                  clearInterval(processingInterval);
                  const actualTime = Math.round((Date.now() - startTime) / 1000);
                  
                  // Create processed PDF for download
                  const processedBlob = downloadUtils.createProcessedPDF(job.fileName, job.tool, job.settings);
                  const downloadUrl = URL.createObjectURL(processedBlob);
                  
                  return {
                    ...job,
                    status: 'completed',
                    progress: 100,
                    downloadUrl,
                    actualTime,
                    outputSize
                  };
                }
                return { ...job, progress: newProgress };
              }
              return job;
            }));
          }, processingDuration / 50);
        }, 500);
      } else {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress } : job
        ));
      }
    }, uploadDuration / 20);
  };

  const removeJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
  };

  const retryJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setJobs(prev => prev.map(j => 
        j.id === jobId 
          ? { ...j, status: 'uploading', progress: 0, error: undefined }
          : j
      ));
      simulateProcessing(jobId, job.estimatedTime || 3, job.outputSize);
    }
  };

  const clearFiles = (toolId: string) => {
    setSelectedFiles(prev => ({
      ...prev,
      [toolId]: []
    }));
    if (fileInputRefs.current[toolId]) {
      fileInputRefs.current[toolId]!.value = '';
    }
  };

  const getStatusIcon = (status: PDFJob['status']) => {
    switch (status) {
      case 'uploading':
      case 'processing':
        return <RefreshCw className="h-4 w-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: PDFJob['status']) => {
    switch (status) {
      case 'uploading':
        return 'Uploading...';
      case 'processing':
        return 'Processing...';
      case 'completed':
        return 'Completed';
      case 'error':
        return 'Error';
    }
  };

  const updateToolSetting = (toolId: string, key: string, value: any) => {
    setToolSettings(prev => ({
      ...prev,
      [toolId]: {
        ...prev[toolId],
        [key]: value
      }
    }));
  };

  const renderToolSettings = (tool: any) => {
    const settings = toolSettings[tool.id] || {};
    
    switch (tool.id) {
      case 'split':
        return (
          <div className="space-y-4 mt-4 p-4 border rounded-lg bg-muted/50">
            <h4 className="font-medium flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Split Options
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="split-from">From Page</Label>
                <Input
                  id="split-from"
                  type="number"
                  placeholder="1"
                  min="1"
                  value={settings.fromPage || ''}
                  onChange={(e) => updateToolSetting(tool.id, 'fromPage', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="split-to">To Page</Label>
                <Input
                  id="split-to"
                  type="number"
                  placeholder="10"
                  min="1"
                  value={settings.toPage || ''}
                  onChange={(e) => updateToolSetting(tool.id, 'toPage', e.target.value)}
                />
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Leave empty to split into individual pages
            </div>
          </div>
        );
      
      case 'compress':
        return (
          <div className="space-y-4 mt-4 p-4 border rounded-lg bg-muted/50">
            <h4 className="font-medium flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Compression Settings
            </h4>
            <div>
              <Label>Quality Level: {settings.quality || 75}%</Label>
              <Slider
                value={[settings.quality || 75]}
                onValueChange={(value) => updateToolSetting(tool.id, 'quality', value[0])}
                max={100}
                min={10}
                step={5}
                className="mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Smaller file</span>
                <span>Better quality</span>
              </div>
            </div>
          </div>
        );
      
      case 'protect':
        return (
          <div className="space-y-4 mt-4 p-4 border rounded-lg bg-muted/50">
            <h4 className="font-medium flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Protection Settings
            </h4>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                value={settings.password || ''}
                onChange={(e) => updateToolSetting(tool.id, 'password', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Permissions</Label>
              <div className="space-y-1">
                <label className="flex items-center space-x-2 text-sm">
                  <input
                    type="checkbox"
                    checked={settings.allowPrint || false}
                    onChange={(e) => updateToolSetting(tool.id, 'allowPrint', e.target.checked)}
                  />
                  <span>Allow printing</span>
                </label>
                <label className="flex items-center space-x-2 text-sm">
                  <input
                    type="checkbox"
                    checked={settings.allowCopy || false}
                    onChange={(e) => updateToolSetting(tool.id, 'allowCopy', e.target.checked)}
                  />
                  <span>Allow copying text</span>
                </label>
              </div>
            </div>
          </div>
        );
      
      case 'watermark':
        return (
          <div className="space-y-4 mt-4 p-4 border rounded-lg bg-muted/50">
            <h4 className="font-medium flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Watermark Settings
            </h4>
            <div>
              <Label htmlFor="watermark-text">Watermark Text</Label>
              <Input
                id="watermark-text"
                placeholder="CONFIDENTIAL"
                value={settings.text || ''}
                onChange={(e) => updateToolSetting(tool.id, 'text', e.target.value)}
              />
            </div>
            <div>
              <Label>Opacity: {settings.opacity || 50}%</Label>
              <Slider
                value={[settings.opacity || 50]}
                onValueChange={(value) => updateToolSetting(tool.id, 'opacity', value[0])}
                max={100}
                min={10}
                step={5}
                className="mt-2"
              />
            </div>
          </div>
        );
      
      case 'rotate':
        return (
          <div className="space-y-4 mt-4 p-4 border rounded-lg bg-muted/50">
            <h4 className="font-medium flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Rotation Settings
            </h4>
            <div>
              <Label>Rotation Angle</Label>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {[90, 180, 270, 360].map(angle => (
                  <Button
                    key={angle}
                    variant={settings.angle === angle ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateToolSetting(tool.id, 'angle', angle)}
                  >
                    {angle}°
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <TooltipProvider>
      <div className="container py-8">
        <div className="mb-8 slide-up">
          <h1 className="text-3xl font-bold mb-2">PDF Tools</h1>
          <p className="text-muted-foreground">
            Professional PDF manipulation tools with advanced settings and high accuracy
          </p>
        </div>

        <Tabs defaultValue="organize" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="organize">Organize</TabsTrigger>
            <TabsTrigger value="edit">Edit</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="extract">Extract</TabsTrigger>
          </TabsList>

          {['organize', 'edit', 'security', 'extract'].map(category => (
            <TabsContent key={category} value={category} className="space-y-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pdfTools.filter(tool => tool.category === category).map((tool) => {
                  const Icon = tool.icon;
                  const files = selectedFiles[tool.id] || [];
                  return (
                    <Card key={tool.id} className="conversion-card group">
                      <CardHeader className="pb-4">
                        <div className="flex items-center gap-3">
                          <div className={`card-icon h-10 w-10 rounded-lg ${tool.color} flex items-center justify-center transition-all duration-300`}>
                            <Icon className="h-5 w-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <CardTitle className="text-lg">{tool.title}</CardTitle>
                              <Tooltip>
                                <TooltipTrigger>
                                  <Info className="h-4 w-4 text-muted-foreground" />
                                </TooltipTrigger>
                                <TooltipContent className="max-w-xs">
                                  <div className="space-y-2">
                                    <p><strong>Accuracy:</strong> {tool.accuracy}%</p>
                                    <p><strong>Avg Time:</strong> {tool.avgTime}</p>
                                    <p><strong>Features:</strong> {tool.features.join(', ')}</p>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <CardDescription className="text-sm">
                              {tool.description}
                            </CardDescription>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="secondary" className="text-xs">
                                {tool.accuracy}% accuracy
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                <Clock className="h-3 w-3 mr-1" />
                                {tool.avgTime}
                              </Badge>
                              {tool.multiFile && (
                                <Badge variant="outline" className="text-xs">
                                  Multi-file
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {/* File Preview */}
                        {files.length > 0 && (
                          <div className="mb-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium">Selected Files:</span>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => clearFiles(tool.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                            {files.slice(0, 3).map((file, index) => (
                              <div key={index} className="file-preview">
                                <div className="flex items-center gap-2">
                                  <FileCheck className="h-4 w-4 text-green-500" />
                                  <span className="text-sm truncate flex-1">{file.name}</span>
                                  <span className="text-xs text-muted-foreground">
                                    {formatFileSize(file.size)}
                                  </span>
                                </div>
                              </div>
                            ))}
                            {files.length > 3 && (
                              <div className="text-xs text-muted-foreground text-center">
                                +{files.length - 3} more files
                              </div>
                            )}
                          </div>
                        )}

                        {renderToolSettings(tool)}
                        
                        <div
                          className={`upload-area mt-4 ${dragOver === tool.id ? 'dragover' : ''}`}
                          onDragOver={(e) => handleDragOver(e, tool.id)}
                          onDragLeave={handleDragLeave}
                          onDrop={(e) => handleDrop(e, tool)}
                        >
                          <div className="floating">
                            <Upload className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            Drag & drop PDF files here
                          </p>
                          <p className="text-xs text-muted-foreground mb-4">
                            {tool.multiFile ? 'Multiple files supported' : 'Single file processing'}
                          </p>
                          <input
                            ref={el => fileInputRefs.current[tool.id] = el}
                            type="file"
                            multiple={tool.multiFile}
                            className="hidden"
                            id={`file-${tool.id}`}
                            accept=".pdf"
                            onChange={(e) => handleFileSelect(e, tool)}
                          />
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              const input = document.getElementById(`file-${tool.id}`) as HTMLInputElement;
                              if (input) {
                                input.click();
                              } else {
                                console.error('File input not found:', `file-${tool.id}`);
                                toast.error('File input not available. Please refresh the page.');
                              }
                            }}
                            className="transition-all duration-200 hover:scale-105"
                          >
                            <Zap className="h-4 w-4 mr-2" />
                            Select PDF Files
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Enhanced Processing Jobs */}
        {jobs.length > 0 && (
          <Card className="mt-8 bounce-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Processing Jobs
              </CardTitle>
              <CardDescription>
                Track the progress of your PDF processing tasks with detailed information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {jobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{job.fileName}</span>
                          <Badge variant="outline" className="text-xs">{job.tool}</Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {getStatusIcon(job.status)}
                            {getStatusText(job.status)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Input: {formatFileSize(job.fileSize)}</span>
                          {job.outputSize && (
                            <span>Output: {formatFileSize(job.outputSize)}</span>
                          )}
                          {job.estimatedTime && job.status !== 'completed' && (
                            <span>Est: {job.estimatedTime}s</span>
                          )}
                          {job.actualTime && (
                            <span className="text-green-600">Completed in {job.actualTime}s</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button 
                          size="sm" 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = job.downloadUrl;
                            const toolPrefix = job.tool.toLowerCase().replace(/\s+/g, '-');
                            link.download = `${toolPrefix}-${job.fileName.replace(/\.[^/.]+$/, '')}-${Date.now()}.pdf`;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            toast.success(`${job.tool} completed - PDF downloaded!`);
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                      
                      {job.status === 'error' && (
                        <Button size="sm" variant="outline" onClick={() => retryJob(job.id)}>
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Retry
                        </Button>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeJob(job.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {(job.status === 'uploading' || job.status === 'processing') && (
                    <div className="space-y-2">
                      <Progress value={job.progress} className="h-2 progress-bar" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round(job.progress)}% complete</span>
                        <span>{job.status === 'uploading' ? 'Uploading...' : 'Processing...'}</span>
                      </div>
                    </div>
                  )}
                  
                  {job.error && (
                    <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded p-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-800 dark:text-red-200">{job.error}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </TooltipProvider>
  );
}