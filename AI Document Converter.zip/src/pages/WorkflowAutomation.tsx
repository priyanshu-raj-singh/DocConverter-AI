import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Workflow, Upload, Download, Settings, CheckCircle, Clock, Target, Zap, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

export default function WorkflowAutomation() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
    toast.success(`Selected ${files.length} file(s) for workflow automation`);
  };

  return (
    <div className="container py-8">
      <div className="mb-8 slide-up">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Workflow className="h-8 w-8 text-primary floating" />
          Workflow Automation
        </h1>
        <p className="text-muted-foreground">
          Create custom automated workflows for document processing
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="conversion-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Workflow className="h-5 w-5" />
              Custom Workflows
            </CardTitle>
            <CardDescription>Automate complex document processing tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="upload-area">
              <div className="floating">
                <Workflow className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Upload Files for Automation</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Create and run automated document workflows
              </p>
              <input
                type="file"
                multiple
                className="hidden"
                id="workflow-files"
                accept=".pdf"
                onChange={handleFileSelect}
              />
              <Button 
                variant="outline"
                onClick={() => document.getElementById('workflow-files')?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Select Files
              </Button>
            </div>

            {selectedFiles.length > 0 && (
              <div className="space-y-2">
                <span className="text-sm font-medium">Files in Workflow: {selectedFiles.length}</span>
                <Badge variant="secondary">Ready for automation</Badge>
              </div>
            )}

            <div className="space-y-2">
              <h4 className="font-medium">Sample Workflow:</h4>
              <div className="flex items-center gap-2 text-sm p-2 bg-muted rounded">
                <Upload className="h-3 w-3" />
                <ArrowRight className="h-3 w-3" />
                <Settings className="h-3 w-3" />
                <ArrowRight className="h-3 w-3" />
                <CheckCircle className="h-3 w-3" />
                <ArrowRight className="h-3 w-3" />
                <Download className="h-3 w-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Automation Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Workflow className="h-4 w-4 text-blue-500" />
                <span>Custom workflows</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Automated processing</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Settings className="h-4 w-4 text-purple-500" />
                <span>Configurable steps</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Quality assurance</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Automation Speed
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Simple workflows:</span>
                <span className="text-muted-foreground">1-3 minutes</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Complex workflows:</span>
                <span className="text-muted-foreground">5-15 minutes</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}