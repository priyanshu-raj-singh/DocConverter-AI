import { createBrowserRouter } from 'react-router-dom';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Converter from '@/pages/Converter';
import AIEditor from '@/pages/AIEditor';
import PDFTools from '@/pages/PDFTools';
import History from '@/pages/History';
import AIAnalysis from '@/pages/AIAnalysis';
import StudyTools from '@/pages/StudyTools';
import ChatPDF from '@/pages/ChatPDF';
import DataVisualization from '@/pages/DataVisualization';
import OCRTools from '@/pages/OCRTools';
import AutoFillForms from '@/pages/AutoFillForms';
import PDFCompare from '@/pages/PDFCompare';
import WebGenerator from '@/pages/WebGenerator';
import RedactionTool from '@/pages/RedactionTool';
import BatchProcessing from '@/pages/BatchProcessing';
import WorkflowAutomation from '@/pages/WorkflowAutomation';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'converter',
        element: <Converter />,
      },
      {
        path: 'ai-editor',
        element: <AIEditor />,
      },
      {
        path: 'pdf-tools',
        element: <PDFTools />,
      },
      {
        path: 'ai-analysis',
        element: <AIAnalysis />,
      },
      {
        path: 'study-tools',
        element: <StudyTools />,
      },
      {
        path: 'chat-pdf',
        element: <ChatPDF />,
      },
      {
        path: 'data-viz',
        element: <DataVisualization />,
      },
      {
        path: 'ocr-tools',
        element: <OCRTools />,
      },
      {
        path: 'auto-fill',
        element: <AutoFillForms />,
      },
      {
        path: 'pdf-compare',
        element: <PDFCompare />,
      },
      {
        path: 'web-generator',
        element: <WebGenerator />,
      },
      {
        path: 'redaction',
        element: <RedactionTool />,
      },
      {
        path: 'batch-processing',
        element: <BatchProcessing />,
      },
      {
        path: 'workflow',
        element: <WorkflowAutomation />,
      },
      {
        path: 'history',
        element: <History />,
      },
    ],
  },
]);