// Enhanced file validation utilities
export const fileValidation = {
  // Validate file type and size
  validateFile: (file: File, allowedTypes: string[], maxSize: number = 50 * 1024 * 1024): { valid: boolean; error?: string } => {
    // Check file type
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!allowedTypes.includes(fileExtension)) {
      return {
        valid: false,
        error: `File type ${fileExtension} not supported. Allowed types: ${allowedTypes.join(', ')}`
      };
    }

    // Check file size
    if (file.size > maxSize) {
      const maxSizeMB = Math.round(maxSize / (1024 * 1024));
      return {
        valid: false,
        error: `File size exceeds ${maxSizeMB}MB limit`
      };
    }

    // Check if file is empty
    if (file.size === 0) {
      return {
        valid: false,
        error: 'File is empty'
      };
    }

    return { valid: true };
  },

  // Format file size for display
  formatFileSize: (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  },

  // Get file type from extension
  getFileType: (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const typeMap: { [key: string]: string } = {
      'pdf': 'PDF',
      'doc': 'Word',
      'docx': 'Word',
      'xls': 'Excel',
      'xlsx': 'Excel',
      'ppt': 'PowerPoint',
      'pptx': 'PowerPoint',
      'jpg': 'Image',
      'jpeg': 'Image',
      'png': 'Image',
      'bmp': 'Image',
      'tiff': 'Image',
      'txt': 'Text',
      'rtf': 'Rich Text',
      'csv': 'CSV'
    };
    return typeMap[extension || ''] || 'Unknown';
  },

  // Check if file is supported for conversion
  isSupportedConversion: (fromType: string, toType: string): boolean => {
    const supportedConversions: { [key: string]: string[] } = {
      'PDF': ['DOCX', 'XLSX', 'PPTX', 'JPG/PNG'],
      'DOCX': ['PDF'],
      'XLSX': ['PDF', 'CSV'],
      'PPTX': ['PDF'],
      'JPG/PNG': ['PDF'],
      'Image': ['PDF']
    };
    
    return supportedConversions[fromType]?.includes(toType) || false;
  }
};

// Enhanced processing utilities
export const processingUtils = {
  // Generate unique job ID
  generateJobId: (): string => {
    return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  },

  // Calculate processing time based on file size and operation
  calculateProcessingTime: (fileSize: number, operation: string, fileCount: number = 1): number => {
    const baseTime = {
      'convert': 3,
      'ai-edit': 8,
      'ocr': 10,
      'compare': 12,
      'merge': 5,
      'compress': 4,
      'protect': 2,
      'watermark': 3,
      'split': 2,
      'extract': 6,
      'translate': 15,
      'summarize': 8,
      'analyze': 10
    }[operation] || 5;

    // Add time based on file size (1 second per 3MB)
    const sizeTime = Math.ceil(fileSize / (3 * 1024 * 1024));
    
    // Add time for multiple files
    const fileCountTime = Math.ceil(fileCount * 0.5);
    
    return Math.max(baseTime + sizeTime + fileCountTime, 2);
  },

  // Generate realistic progress updates
  createProgressUpdater: (
    jobId: string, 
    totalTime: number, 
    onProgress: (jobId: string, progress: number, status: string) => void,
    onComplete: (jobId: string, result: any) => void,
    onError?: (jobId: string, error: string) => void
  ) => {
    const phases = [
      { name: 'uploading', duration: 0.2, label: 'Uploading...' },
      { name: 'processing', duration: 0.7, label: 'Processing...' },
      { name: 'finalizing', duration: 0.1, label: 'Finalizing...' }
    ];

    let currentPhase = 0;
    let phaseProgress = 0;
    const startTime = Date.now();

    const updateProgress = () => {
      if (currentPhase >= phases.length) {
        onComplete(jobId, { success: true, time: Math.round((Date.now() - startTime) / 1000) });
        return;
      }

      const phase = phases[currentPhase];
      const increment = Math.random() * 8 + 2; // 2-10% increments
      phaseProgress += increment;

      if (phaseProgress >= 100) {
        phaseProgress = 100;
        const totalProgress = (currentPhase * 100 + phaseProgress) / phases.length;
        onProgress(jobId, Math.min(totalProgress, 99), phase.label);
        
        currentPhase++;
        phaseProgress = 0;
        
        if (currentPhase < phases.length) {
          setTimeout(updateProgress, 200);
        } else {
          setTimeout(() => onComplete(jobId, { success: true, time: Math.round((Date.now() - startTime) / 1000) }), 500);
        }
      } else {
        const totalProgress = (currentPhase * 100 + phaseProgress) / phases.length;
        onProgress(jobId, Math.min(totalProgress, 99), phase.label);
        setTimeout(updateProgress, (totalTime * 1000 * phase.duration) / 50);
      }
    };

    updateProgress();
  }
};

// Enhanced UI utilities
export const uiUtils = {
  // Show toast with proper error handling
  showToast: (type: 'success' | 'error' | 'info', message: string) => {
    // This will be imported from sonner in the actual components
    console.log(`${type.toUpperCase()}: ${message}`);
  },

  // Animate element entrance
  animateEntrance: (element: HTMLElement, delay: number = 0) => {
    setTimeout(() => {
      element.classList.add('slide-up');
    }, delay);
  },

  // Handle file drop with visual feedback
  handleFileDrop: (
    event: DragEvent,
    onFiles: (files: File[]) => void,
    allowedTypes: string[]
  ) => {
    event.preventDefault();
    const files = Array.from(event.dataTransfer?.files || []);
    
    if (files.length === 0) {
      uiUtils.showToast('error', 'No files detected');
      return;
    }

    // Validate all files before processing
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const validation = fileValidation.validateFile(file, allowedTypes);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      uiUtils.showToast('error', `Validation errors:\n${errors.join('\n')}`);
    }

    if (validFiles.length > 0) {
      onFiles(validFiles);
      uiUtils.showToast('success', `${validFiles.length} file(s) ready for processing`);
    }
  }
};