import { Outlet } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import Header from '@/components/Header';
import { ThemeProvider } from '@/components/ThemeProvider';

export default function Layout() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="document-converter-theme">
      <div className="min-h-screen bg-background">
        <Header />
        <main>
          <Outlet />
        </main>
        <Toaster />
      </div>
    </ThemeProvider>
  );
}